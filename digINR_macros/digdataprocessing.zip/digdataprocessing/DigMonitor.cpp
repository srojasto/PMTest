#include "includes/DigMonitor.h"

ClassImp(MyMainFrame);
ClassImp(ParametersFrame);

//----------------------------------
void ParametersFrame::DOtimer(){

	int NenabledCh = DigEvData->GetDataRecipe()->GetConfiguration()->NenableCh;
	//norming time operation, sec
	float weight1 = 55. * StatProc * NenabledCh/17.;
	float weight2 = 55. * StatSave;
	float weight3 = 20. * StatProc * NenabledCh/17.;
	float weight4 = 1.  * StatSave;
	float summWeght = weight1+weight2+weight3+weight4;

	float FullPercent=0;

	switch(gProcessState->step){
	case 1: FullPercent = ( weight1 * gProcessState->percent )/summWeght; break;
	case 2: FullPercent = ( weight2 * gProcessState->percent + weight1)/summWeght; break;
	case 3: FullPercent = ( weight3 * gProcessState->percent + weight1+weight2)/summWeght; break;
	case 4: FullPercent = ( weight4 * gProcessState->percent + weight1+weight2+weight3)/summWeght; break;
	}

	time_t current_time = time(NULL);
	int proc_sec = difftime(current_time, start_time);
	int time_est = (FullPercent == 0)?0:proc_sec/FullPercent*(1. - FullPercent);

	statusLabel->SetText( Form("%s: (%.2d%%)",gProcessState->GetStepName(),gProcessState->GetPercent()) );

	ProgressBar->ShowPosition(kTRUE, kFALSE,
			Form("%s  (%3.0dm %2.0is) [%3.0dm %2.0is]","%.0f\%",proc_sec/60, proc_sec%60, (time_est/60), time_est%60 ));
	ProgressBar->Increment( FullPercent*100. - ProgressBar->GetPosition() );
}

//----------------------------------
void ParametersFrame::DOcalculate(){

	if(gProcessState->step != 0){ gProcessState->break_flag=1; return; }


	if(VERBOSE > 1)printf("Saving data ... \n");

	gProcessState->enabled = 1;
	gProcessState->break_flag = 0;
	ProgressBar->Reset();

	DigDataRecipe *DataRecipe = DigEvData->GetDataRecipe();
	DigDataAnalysis *Analysis = new DigDataAnalysis(gProcessState);

	StatSave = NEstat_s->GetIntNumber();
	StatProc = NEstat_p->GetIntNumber();

	DataRecipe->GetProcParam()->Statistic = StatProc;
	DataRecipe->GetMainDetault()->minAmplitude = NEampl_min->GetNumber();

	Analysis->SetStudyEv( StatProc );
	Analysis->SetAmplRange( NEampl_rng->GetNumber() );

	Analysis->SetCRTLgroupNameMask( crtlGroupMask->GetText() );

	DataRecipe->BuildParameters();
	DataRecipe->PrintOut();

	//filling start detectors list
	TList *StartDetList = new TList;
	StartDetList ->Clear(); LstartCH->GetSelectedEntries(StartDetList);
	DataRecipe->ClearEssentialChList();

	int NumStartDetectors = 0;
	while(StartDetList->At(NumStartDetectors)) NumStartDetectors++;

	if(NumStartDetectors < 1){
		statusLabel->SetText("Unspecified start detector");
		if(Analysis) delete Analysis;
		return;
	}


	//Setting start detectors
	if(VERBOSE >= 4)printf("\nSetting start detector:\n");
	for(int nlist=0; nlist<NumStartDetectors;nlist++){
		int Ch = ( (TGLBEntry*) (StartDetList->At(nlist)) )->EntryId();
		char StartDetectorName[MAX_NAME_LENGHT];
		strcpy(StartDetectorName, DataRecipe->GetConfiguration()->ChannelConfig[Ch].ChName);
		//printf("debug: trg %i\n",Ch);
		DataRecipe->AddEssentialChannel(StartDetectorName,1);
		Analysis->AddStartDetector(StartDetectorName, ((Ch < 8)||(Ch == 16)?0:1));
		if(VERBOSE >= 4)printf("%s\n", DataRecipe->GetConfiguration()->ChannelConfig[Ch].ChName);

	}

	//default selection start GR1
	//    int startGR1pmt1 = DigEvData->GetDataRecipe()->FindChannelByName("T0_C2") > 0;
	//    int startGR1pmt2 = DigEvData->GetDataRecipe()->FindChannelByName("T0_D2") > 0;


	//    if( 0 <= startGR1pmt1 &&  0 <= startGR1pmt2){
	//        Analysis->AddStartDetector("T0_C2", 1);
	//        Analysis->AddStartDetector("T0_D2", 1);
	//        if(VERBOSE >= 4)printf("T0_C2\n");
	//        if(VERBOSE >= 4)printf("T0_D2\n");
	//    }else{
	//        int startGR1Trg;
	//        if(startGR1Trg = DigEvData->GetDataRecipe()->FindChannelByName("TRG2") > 0){
	//            Analysis->AddStartDetector("TRG2", 1);
	//            if(VERBOSE >= 4)printf("TRG2\n");
	//        }
	//    }




	//choose file name
	static TString dir(".");
	const char *filetypes[] = { "ROOT files",    "*.root",
			"All files",     "*",
			0,               0};
	TGFileInfo fi;
	fi.fFileTypes = filetypes;
	fi.fIniDir    = StrDup(".");
	new TGFileDialog(gClient->GetRoot(), this, kFDSave, &fi);

	dir = fi.fIniDir;

	if(fi.fFilename != 0){
		char FileName[MAXLINE]; strcpy(FileName, fi.fFilename);

		if(gProcessState->step == 0){
			gProcessState->SetStatus(1,0.);
			Bcalculate->SetText(" BREAK ");
		}

		Timer->TurnOn();
		Timer->Start(200);
		start_time = time(NULL);
		gSystem->ProcessEvents();

		try{
			statusLabel->SetText("saving tree ... ");
			gSystem->ProcessEvents();
			DigEvData->SaveDataAsTree(FileName,StatSave);

			statusLabel->SetText("analysing data ... ");
			gSystem->ProcessEvents();
			Analysis->AnalyseFile(FileName);

		}
		catch(int a){
			if(a == 1){
				if(VERBOSE > 1)printf("*\n*\n*\ndata process interrupted\n");
				statusLabel->SetText("data process interrupted");
				gSystem->ProcessEvents();
			}
		}


		Timer->TurnOff();
		Timer->Stop();

		ProgressBar->Increment( 100. - ProgressBar->GetPosition() );
		statusLabel->SetText("analysed");
		gSystem->ProcessEvents();

		gProcessState->SetStatus(0,0.);
		Bcalculate->SetText("SAVE AS");

		delete StartDetList;
		delete Analysis;

	}

}
//----------------------------------
void ParametersFrame::DOreset(){

	int MaxEv = DigEvData->GetEvent(0)->GetTotalEvents();
	int MinEv = 10000; if(MinEv > MaxEv) MinEv = MaxEv;

	NEstat_p->SetLimitValues(MinEv,MaxEv);
	NEstat_p->SetIntNumber(MinEv);
	NEstat_s->SetLimitValues(MinEv,MaxEv);
	NEstat_s->SetIntNumber(MaxEv);

	NEampl_min->SetLimitValues(0,1000);
	NEampl_min->SetIntNumber(150);

	NEampl_rng->SetLimitValues(0.,1);
	NEampl_rng->SetIntNumber(0);

	ProgressBar->Reset();

	LstartCH->RemoveAll();

	int firstActCh = -1;
	ChConfiguration *ChConfig = DigEvData->GetDataRecipe()->GetConfiguration()->ChannelConfig;
	for(int Ch=0; Ch<MAX_CH;Ch++)
		if(ChConfig[Ch].IsEnable){
			LstartCH->AddEntry(Form("[%.2d] %s",Ch,ChConfig[Ch].ChName), Ch);
			if(firstActCh == -1)firstActCh = Ch;
		}

	//default selection
	int PMT10, PMT20, Trg0, PMT11, PMT21, Trg1;


	if( (PMT10 = DigEvData->GetDataRecipe()->FindChannelByName("T0_C1")) > 0 ) LstartCH->Select(PMT10);
	if( (PMT20 = DigEvData->GetDataRecipe()->FindChannelByName("T0_D1")) > 0 ) LstartCH->Select(PMT20);

	if( (PMT11 = DigEvData->GetDataRecipe()->FindChannelByName("T0_C2")) > 0 ) LstartCH->Select(PMT11);
	if( (PMT21 = DigEvData->GetDataRecipe()->FindChannelByName("T0_D2")) > 0 ) LstartCH->Select(PMT21);

	if(PMT10 < 0 && PMT20 < 0)
		if((Trg0 = DigEvData->GetDataRecipe()->FindChannelByName("TRG1")) > 0) LstartCH->Select(Trg0);

	if(PMT11 < 0 && PMT21 < 0)
		if((Trg1 = DigEvData->GetDataRecipe()->FindChannelByName("TRG2")) > 0) LstartCH->Select(Trg1);



	LstartCH->SetTopEntry(firstActCh);
	LstartCH->Resize(300,100);

	if(VERBOSE > 1)printf("Data parameters reseted\n");

}

//----------------------------------
ParametersFrame::ParametersFrame(DigData *Data_, const TGWindow *p, UInt_t w, UInt_t h, GlobalProcessStatus *state){

	gProcessState = state;
	DigEvData = Data_;

	TGVerticalFrame *main_frame = new TGVerticalFrame(this, FrameLenght, 1000); //main area
	AddFrame(main_frame, new TGLayoutHints(kLHintsExpandX| kLHintsExpandY, 2, 2, 2, 2));

	FrameLenght = 360;

	//timer
	Timer = new TTimer(200,1);
	Timer->Connect("Timeout()","ParametersFrame",this,"DOtimer()");
	gProcessState->enabled = 1;

	//statistic:
	TGGroupFrame *FRstatistic = new TGGroupFrame(main_frame, "Statistic",kVerticalFrame);//frame for event stats
	main_frame->AddFrame(FRstatistic, new TGLayoutHints(kLHintsExpandX,2,2,2,2));

	TGHorizontalFrame *stat1Frame = new TGHorizontalFrame(FRstatistic, FrameLenght, 200);
	FRstatistic->AddFrame(stat1Frame, new TGLayoutHints(kLHintsExpandX| kLHintsExpandY, 2, 2, 2, 2));

	TGLabel *statLabel1 = new TGLabel(stat1Frame, "study: "); statLabel1->SetTextJustify(kTextLeft|kTextBottom);
	stat1Frame->AddFrame(statLabel1, new TGLayoutHints(kLHintsExpandX,0,2,2,2));

	NEstat_p = new TGNumberEntry(stat1Frame, 1,0,999,TGNumberFormat::kNESInteger, TGNumberFormat::kNEANonNegative, TGNumberFormat::kNELLimitMinMax);
	stat1Frame->AddFrame(NEstat_p, new TGLayoutHints(kLHintsExpandX,0,2,2,2));


	TGHorizontalFrame *stat2Frame = new TGHorizontalFrame(FRstatistic, FrameLenght, 200);
	FRstatistic->AddFrame(stat2Frame, new TGLayoutHints(kLHintsExpandX| kLHintsExpandY, 2, 2, 2, 2));

	TGLabel *statLabel2 = new TGLabel(stat2Frame, "process: "); statLabel2->SetTextJustify(kTextLeft|kTextBottom);
	stat2Frame->AddFrame(statLabel2, new TGLayoutHints(kLHintsExpandX,0,2,2,2));

	NEstat_s = new TGNumberEntry(stat2Frame, 1,0,999,TGNumberFormat::kNESInteger, TGNumberFormat::kNEANonNegative, TGNumberFormat::kNELLimitMinMax);
	stat2Frame->AddFrame(NEstat_s, new TGLayoutHints(kLHintsExpandX,0,2,2,2));

	//amplitude
	TGGroupFrame *FRamplitude = new TGGroupFrame(main_frame, "Amplitude",kVerticalFrame);//frame for amplitude param
	main_frame->AddFrame(FRamplitude, new TGLayoutHints(kLHintsExpandX,2,2,2,2));

	TGHorizontalFrame *ampl1Frame = new TGHorizontalFrame(FRamplitude, FrameLenght, 200);
	FRamplitude->AddFrame(ampl1Frame, new TGLayoutHints(kLHintsExpandX| kLHintsExpandY, 2, 2, 2, 2));

	TGLabel *amplLabel1 = new TGLabel(ampl1Frame, "min, mV: "); amplLabel1->SetTextJustify(kTextLeft|kTextBottom);
	ampl1Frame->AddFrame(amplLabel1, new TGLayoutHints(kLHintsExpandX,0,2,2,2));

	NEampl_min = new TGNumberEntry(ampl1Frame, 1,1,999, TGNumberFormat::kNESRealOne, TGNumberFormat::kNEANonNegative, TGNumberFormat::kNELLimitMinMax);
	ampl1Frame->AddFrame(NEampl_min, new TGLayoutHints(kLHintsExpandX,0,2,2,2));


	TGHorizontalFrame *ampl2Frame = new TGHorizontalFrame(FRamplitude, FrameLenght, 200);
	FRamplitude->AddFrame(ampl2Frame, new TGLayoutHints(kLHintsExpandX| kLHintsExpandY, 2, 2, 2, 2));

	TGLabel *amplLabel2 = new TGLabel(ampl2Frame, "range, sigma: "); amplLabel2->SetTextJustify(kTextLeft|kTextBottom);
	ampl2Frame->AddFrame(amplLabel2, new TGLayoutHints(kLHintsExpandX,0,2,2,2));

	NEampl_rng = new TGNumberEntry(ampl2Frame, 1,1,999, TGNumberFormat::kNESRealOne, TGNumberFormat::kNEANonNegative, TGNumberFormat::kNELLimitMinMax);
	ampl2Frame->AddFrame(NEampl_rng, new TGLayoutHints(kLHintsExpandX,0,2,2,2));

	//options
	TGGroupFrame *FRoption = new TGGroupFrame(main_frame, "Options",kVerticalFrame);//frame for amplitude param
	main_frame->AddFrame(FRoption, new TGLayoutHints(kLHintsExpandX,2,2,2,2));

	TGHorizontalFrame *option1Frame = new TGHorizontalFrame(FRoption, FrameLenght, 200);
	FRoption->AddFrame(option1Frame, new TGLayoutHints(kLHintsExpandX| kLHintsExpandY, 2, 2, 2, 2));

	TGLabel *optionLabel1 = new TGLabel(option1Frame, "crtlk group mask: "); optionLabel1->SetTextJustify(kTextLeft|kTextBottom);
	option1Frame->AddFrame(optionLabel1, new TGLayoutHints(kLHintsExpandX,0,2,2,2));

	crtlGroupMask = new TGTextEntry(option1Frame, new TGTextBuffer(20)); //current event may be set by user  kSunkenFrame | kDoubleBorder
	option1Frame->AddFrame(crtlGroupMask, new TGLayoutHints(kLHintsExpandX,0,2,2,2));
	crtlGroupMask->SetText("5MCP%i;5CFD%i");

	//start detector
	TGGroupFrame *FRstartd = new TGGroupFrame(main_frame, "Start detectors",kVerticalFrame);//frame for start detectors list
	main_frame->AddFrame(FRstartd, new TGLayoutHints(kLHintsExpandX,2,2,2,2));

	//    TGLabel *startLabel1 = new TGLabel(FRstartd, "       GROUP#1         GROUP#2"); startLabel1->SetTextJustify(kTextLeft|kTextBottom);
	//    FRstartd->AddFrame(startLabel1, new TGLayoutHints(kLHintsExpandX,0,2,2,2));

	TGHorizontalFrame *startFrame = new TGHorizontalFrame(FRstartd, FrameLenght, 500);
	FRstartd->AddFrame(startFrame, new TGLayoutHints(kLHintsExpandX| kLHintsExpandY, 2, 2, 2, 2));


	LstartCH = new TGListBox(startFrame, MAX_CH); LstartCH->SetMultipleSelections(kTRUE);//list of enabled channels
	startFrame->AddFrame(LstartCH, new TGLayoutHints(kLHintsTop | kLHintsLeft |
			kLHintsExpandX | kLHintsExpandY,
			5, 5, 5, 5));

	//    LstartCHgr1 = new TGListBox(startFrame, MAX_CH); LstartCHgr1->SetMultipleSelections(kTRUE);//list of enabled channels
	//    startFrame->AddFrame(LstartCHgr1, new TGLayoutHints(kLHintsTop | kLHintsLeft |
	//                                                     kLHintsExpandX | kLHintsExpandY,
	//                                                     5, 5, 5, 5));


	//status
	TGGroupFrame *FRstatus = new TGGroupFrame(main_frame, "Status", kVerticalFrame);//frame for start detectors list
	main_frame->AddFrame(FRstatus, new TGLayoutHints(kLHintsExpandX,2,2,2,2));

	TGVerticalFrame *statusFrame = new TGVerticalFrame(FRstatus, FrameLenght, 500);
	FRstatus->AddFrame(statusFrame, new TGLayoutHints(kLHintsExpandX| kLHintsExpandY, 2, 2, 2, 2));

	statusLabel = new TGLabel(statusFrame, "setting parameters ... ");
	statusFrame->AddFrame(statusLabel, new TGLayoutHints(kLHintsExpandX,0,2,2,2));

	ProgressBar = new TGHProgressBar(statusFrame, 300);
	ProgressBar->SetRange(0.,100.);
	ProgressBar->ShowPosition();
	statusFrame->AddFrame(ProgressBar, new TGLayoutHints(kLHintsExpandX,0,2,2,2));

	//buttons
	TGHorizontalFrame *buttonsFrame = new TGHorizontalFrame(main_frame, FrameLenght, 200);
	main_frame->AddFrame(buttonsFrame, new TGLayoutHints(kLHintsExpandX| kLHintsExpandY, 2, 2, 2, 2));

	Breset = new TGTextButton(buttonsFrame,"RESET");
	Breset->Connect("Clicked()","ParametersFrame",this,"DOreset()");
	buttonsFrame->AddFrame(Breset, new TGLayoutHints(kLHintsLeft,1,1,1,1));

	Bcalculate = new TGTextButton(buttonsFrame,"SAVE AS");
	Bcalculate->Connect("Clicked()","ParametersFrame",this,"DOcalculate()");
	buttonsFrame->AddFrame(Bcalculate, new TGLayoutHints(kLHintsLeft,1,1,1,1));

	DOreset();

	this->SetIconPixmap("icon.png");
	MapSubwindows();

	// Initialize the layout algorithm via Resize()
	this->Resize(250,500);

	// Map main frame
	MapWindow();
	this->SetWindowName("Data Parameters");
	this->Connect("CloseWindow()", "MyMainFrame", this, "CloseWindow()");

}

ParametersFrame::~ParametersFrame(){
	Cleanup();
}

void ParametersFrame::CloseWindow(){
	delete this;
}


//------------------------------
void MyMainFrame::DOparameters(){
	if(DigEvData == 0)
	{
		if(VERBOSE > 1) printf("ERROR: Data was not opened for calculation\n");
		return;
	}

	if(DigEvData->GetDataRecipe()->GetConfiguration()->IsConfigured <= 0)
	{
		if(VERBOSE > 1) printf("ERROR: Data was not opened for calculation\n");
		return;
	}

	new ParametersFrame(DigEvData, gClient->GetRoot(), 3000, 400, gProcessState);
	show_ongoing = 0;
}

//------------------------------
void MyMainFrame::DOopen(){

	static TString dir(".");
	const char *filetypes[] = { "Config Files",   "DataConfig.txt",
			"Text files",     "*.[tT][xX][tT]",
			"All files",      "*",
			0,               0 };

	TGFileInfo *fi = new TGFileInfo;
	fi->fFileTypes = filetypes;
	fi->fIniDir    = StrDup(".");
	TGFileDialog *FileWin = new TGFileDialog(gClient->GetRoot(), this, kFDOpen, fi);

	dir = fi->fIniDir;
	if(fi->fFilename != 0){
		SetFileName(fi->fFilename);
		LoadFiles();
	}

	//FileWin->Cleanup();
	//delete FileWin;
	delete fi;



}

//------------------------------
void MyMainFrame::ReDivideCanvas(){

	ChList->Clear(); fChannelList->GetSelectedEntries(ChList);

	//num_ch_to_show = ChList->GetEntries();


	num_ch_to_show =0;
	while(ChList->At(num_ch_to_show)) num_ch_to_show++;

	TCanvas *ShCanvas = fEcanvas->GetCanvas();
	ShCanvas->Clear();

	int nlines, ncolumns;
	if(num_ch_to_show > 0){
		ncolumns = ceil(TMath::Sqrt( num_ch_to_show ));
		nlines = ceil(num_ch_to_show/(float)ncolumns);

		ShCanvas->Divide(nlines,ncolumns);
	}

	ShCanvas->Update();
	//ChList->ls();
	//printf("%d [%d, %d]\n",num_ch_to_show,nlines, ncolumns);

}
//------------------------------
void MyMainFrame::LoadFiles(){
	if(VERBOSE>0)printf("DigMonitor::LoadFiles: Loading file: %s\n", FileName.Data());
	char fname[MAXLINE]; strcpy(fname,FileName.Data());

	if(DigEvData) delete DigEvData;
	DigEvData = new DigData(gProcessState);

	if( DigEvData->OpenData(fname) == 1 )
	{
		InfoLabel->SetText(Form("%s; \"%s\"",DigEvData->GetDataRecipe()->GetConfiguration()->DataName,DigEvData->GetDataRecipe()->GetConfiguration()->RunComment));
		DigEvData->GetDataRecipe()->PrintOut();
		TotalEvents = DigEvData->GetEvent(0)->GetTotalEvents();

		CurEvent = 0; show_ongoing = 1;
		EvLabel1->SetText(Form("Total: %14d", TotalEvents));
		EvEdit->SetText(Form("%d",CurEvent));

		fChannelList->RemoveAll();
		//fChannelList->Layout();

		ChConfiguration *ChConfig = DigEvData->GetDataRecipe()->GetConfiguration()->ChannelConfig;
		for(int Ch=0; Ch<MAX_CH;Ch++)
			if(ChConfig[Ch].IsEnable){
				fChannelList->AddEntry(Form("[%.2d] %s",Ch,ChConfig[Ch].ChName), Ch);
			}

		fChannelList->MapSubwindows();
		fChannelList->Layout();
		fChannelList->Resize(200,300);

	}

}
//------------------------------
void MyMainFrame::ShowEvLoop(int EventsToShow){

	TCanvas *ShCanvas = fEcanvas->GetCanvas();

	CurEvent = atoi( EvEdit->GetText() );

	DigEvent *CurEvent_ptr;
	if(DigEvData->GetDataRecipe()->GetConfiguration()->IsConfigured < 3)
		show_ongoing = 0;

	TGraph *currGraph = 0;
	MAIN_signal *SignalParam = 0;

	Float_t x[6] = {0.,0.,0.,0.,0.,0.};
	Float_t y[6] = {0.,0.,0.,0.,0.,0.};

	int ShowedEvent = 0;
	while(show_ongoing){
		TotalEvents = DigEvData->GetEvent(0)->GetTotalEvents();
		EvLabel1->SetText(Form("Total: %14d", TotalEvents));


		if(CurEvent < TotalEvents-1){ //if new events exist

			for(int nlist=0; nlist<num_ch_to_show;nlist++){
				int Ch = ( (TGLBEntry*) (ChList->At(nlist)) )->EntryId();
				ShCanvas->cd(nlist+1);

				CurEvent_ptr = DigEvData->GetEvent(CurEvent);
				currGraph = CurEvent_ptr->GetChannel(Ch)->GetSignalGraph();

				if(!IsInspect->IsOn())
				{
					InfoLabel->SetText(Form("%s; \"%s\"",DigEvData->GetDataRecipe()->GetConfiguration()->DataName,DigEvData->GetDataRecipe()->GetConfiguration()->RunComment));
					// disable drawing fit function
					if(currGraph->GetFunction("SignalFront_pol1"))
						currGraph->GetFunction("SignalFront_pol1")->SetRange(0., 0.);
				}


				currGraph->Draw("ACP");

				if(IsInspect->IsOn())
				{
					CurEvent_ptr->CalculateEvent();

					CurEvent_ptr->GetChannel(Ch)->GetSignal(&SignalParam);
					x[0] = SignalParam->time_begin;
					x[1] = SignalParam->time_front_end;
					x[2] = SignalParam->time_peak;
					x[3] = SignalParam->time_back_begin;
					x[4] = SignalParam->time_end;
					x[5] = SignalParam->time_begin-10.; //zero level


					y[0] = currGraph->Eval(x[0]);
					y[1] = currGraph->Eval(x[1]);
					y[2] = currGraph->Eval(x[2]);
					y[3] = currGraph->Eval(x[3]);
					y[4] = currGraph->Eval(x[4]);
					y[5] = SignalParam->ZeroLevel;
					SignalMarkers->Draw();

					SignalMarkers->SetPolyMarker(6, x, y);

					InfoLabel->SetText(Form("CH[%i]: Time %.2f, Time_pol1 %.2f, Chi %.1f, Ampl %.1f, Zero Level %.2f, tm_fr_beg %.2f, tm_fr_end %.2f, tm_bk_beg %.2f, tm_bk_end %.2f, tm_ampl %.2f",
							Ch, SignalParam->Time, SignalParam->Time_pol1, CurEvent_ptr->GetChannel(Ch)->GetSignalFitFunc_pol1()->GetChisquare(),
							SignalParam->Amplitude, SignalParam->ZeroLevel, x[0], x[1], x[3], x[4], x[2]));
				}

				ShCanvas->Modified();
				ShCanvas->Update();

			} //channels loop
			CurEvent++;
			ShowedEvent++;
		}//if new events exist


		EvEdit->SetText(Form("%d",CurEvent));

		gSystem->ProcessEvents();
		if(  (ShowedEvent >= EventsToShow) && (EventsToShow != 0)  )show_ongoing = 0;
		if(!show_ongoing) break;
		gSystem->Sleep(show_speed);



		gSystem->ProcessEvents();

	}

}
//------------------------------
void MyMainFrame::CloseWindow()
{
	if(VERBOSE>0)printf("DigMonitor::CloseWindow: Closing window ...\n");
	show_ongoing = 0;
	if(DigEvData) delete DigEvData;
	if(ChList) delete ChList;
	if(SignalMarkers) delete SignalMarkers;

	gROOT -> CloseFiles();
	gDirectory -> Clear();

	printf("debug: END\n");

	gApplication->Terminate(0);
}
//------------------------------
MyMainFrame::MyMainFrame(const TGWindow *p, UInt_t w, UInt_t h, GlobalProcessStatus *state) :
    		TGMainFrame(p, w, h)
{
	gProcessState = state;

	int panel_width = 200;
	TGHorizontalFrame *panel_wspace = new TGHorizontalFrame(this, 1000, 1000); //main area
	AddFrame(panel_wspace, new TGLayoutHints(kLHintsExpandX| kLHintsExpandY, 2, 2, 2, 2));

	TGVerticalFrame  *panel = new TGVerticalFrame (panel_wspace, panel_width, 100, kFixedWidth); //parameters panel
	panel_wspace->AddFrame(panel, new TGLayoutHints(kLHintsExpandY, 2, 2, 2, 2));

	TGVerticalFrame *wspace = new TGVerticalFrame(panel_wspace, 400, 400); //space for drawing
	panel_wspace->AddFrame(wspace, new TGLayoutHints(kLHintsExpandX| kLHintsExpandY, 2, 2, 2, 2));

	InfoLabel = new TGLabel(wspace,"Data not loaded");
	wspace->AddFrame(InfoLabel, new TGLayoutHints(kLHintsExpandX,0,2,2,2));
	InfoLabel->ChangeOptions(InfoLabel->GetOptions() | kFixedSize);
	InfoLabel->Resize(350, 40);

	fEcanvas = new TRootEmbeddedCanvas("Ecanvas",wspace,500,500);// Create canvas widget for graphics
	wspace->AddFrame(fEcanvas, new TGLayoutHints(kLHintsExpandX| kLHintsExpandY,2,2,2,2));

	TGGroupFrame *EventStatf = new TGGroupFrame(panel, "Event statistic",kVerticalFrame);//frame for event stats
	panel->AddFrame(EventStatf, new TGLayoutHints(kLHintsExpandX,2,2,2,2));

	EvLabel1 = new TGLabel(EventStatf, "EMPTY"); EvLabel1->SetTextJustify(kTextLeft|kTextBottom);//total events
	EventStatf->AddFrame(EvLabel1, new TGLayoutHints(kLHintsExpandX,0,2,2,2));

	TGHorizontalFrame *panel_curev = new TGHorizontalFrame(EventStatf, 100, 30); //horisontal space fo current event
	EventStatf->AddFrame(panel_curev, new TGLayoutHints(kLHintsExpandX,2,2,2,2));

	EvLabel2 = new TGLabel(panel_curev, "Current:"); EvLabel2->SetTextJustify(kTextLeft|kTextBottom); //"current"
	panel_curev->AddFrame(EvLabel2, new TGLayoutHints(kLHintsExpandX,0,0,2,2));

	EvEdit = new TGTextEntry(panel_curev, new TGTextBuffer(10)); //current event may be set by user  kSunkenFrame | kDoubleBorder
	panel_curev->AddFrame(EvEdit, new TGLayoutHints(kLHintsLeft,0,0,2,2));

	TGHorizontalFrame *ssbuttons = new TGHorizontalFrame(EventStatf, panel_width, 30); //start stop buttons area
	EventStatf->AddFrame(ssbuttons, new TGLayoutHints(kLHintsExpandX,0,0,0,0));

	Bstart = new TGTextButton(ssbuttons,"START");
	Bstart->Connect("Clicked()","MyMainFrame",this,"DOstart()");
	ssbuttons->AddFrame(Bstart, new TGLayoutHints(kLHintsLeft,1,1,1,1));

	Bstop = new TGTextButton(ssbuttons,"STOP");
	Bstop->Connect("Clicked()","MyMainFrame",this,"DOstop()");
	ssbuttons->AddFrame(Bstop, new TGLayoutHints(kLHintsLeft,1,1,1,1));

	Bnext = new TGTextButton(ssbuttons,"NEXT");
	Bnext->Connect("Clicked()","MyMainFrame",this,"DOnext()");
	ssbuttons->AddFrame(Bnext, new TGLayoutHints(kLHintsLeft,1,1,1,1));

	Bstartfb = new TGTextButton(ssbuttons,"CONTINUE");
	Bstartfb->Connect("Clicked()","MyMainFrame",this,"DOcontinue()");
	ssbuttons->AddFrame(Bstartfb, new TGLayoutHints(kLHintsLeft,1,1,1,1));


	IsInspect = new TGCheckButton(EventStatf, "INSPECT"); //current event may be set by user  kSunkenFrame | kDoubleBorder
	EventStatf->AddFrame(IsInspect, new TGLayoutHints(kLHintsLeft,0,0,2,2));

	fChannelList = new TGListBox(panel); fChannelList->SetMultipleSelections(kTRUE);//list of enabled channels
	fChannelList->Connect("SelectionChanged()", "MyMainFrame", this, "ReDivideCanvas()");
	panel->AddFrame(fChannelList, new TGLayoutHints(kLHintsTop | kLHintsLeft |
			kLHintsExpandX | kLHintsExpandY,
			5, 5, 5, 5));

	Bopen = new TGTextButton(panel,"OPEN DATA");
	Bopen->Connect("Clicked()","MyMainFrame",this,"DOopen()");
	panel->AddFrame(Bopen, new TGLayoutHints(kLHintsExpandX,5,5,5,5));

	Bparameters = new TGTextButton(panel,"CALCULATE DATA");
	Bparameters->Connect("Clicked()","MyMainFrame",this,"DOparameters()");
	panel->AddFrame(Bparameters, new TGLayoutHints(kLHintsExpandX,5,5,5,5));

	Bbrowser = new TGTextButton(panel,"OPEN ROOT Browser");
	Bbrowser->Connect("Clicked()","MyMainFrame",this,"DObrowser()");
	panel->AddFrame(Bbrowser, new TGLayoutHints(kLHintsExpandX,5,5,5,5));

	this->SetIconPixmap("icon.png");
	this->Connect("CloseWindow()", "MyMainFrame", this, "CloseWindow()");
	SetWindowName("Digitizer events monitoring");

	// Set a name to the main frame

	MapSubwindows();

	// Initialize the layout algorithm via Resize()
	Resize(GetDefaultSize());

	// Map main frame
	MapWindow();

	show_speed = 0;
	DigEvData = new DigData(gProcessState);
	DigEvData = NULL;
	ChList = new TList;

	SignalMarkers = new TPolyMarker();
	SignalMarkers->SetMarkerStyle(3);
	SignalMarkers->SetMarkerSize(1);
	SignalMarkers->SetMarkerColor(2);


	ReDivideCanvas();
}

MyMainFrame::~MyMainFrame(){
	Cleanup();
	DeleteWindow();
}

void MyMainFrame::DOstart(){
	show_ongoing = 1;
	ShowEvLoop(0);
}
void MyMainFrame::DOstop(){
	show_ongoing = 0;
}
void MyMainFrame::DOnext(){
	show_ongoing = 1;
	ShowEvLoop(1);
}
void MyMainFrame::DOcontinue(){
	EvEdit->SetText(Form("%d",TotalEvents));
	CurEvent = TotalEvents; DOstart();
}
void MyMainFrame::DObrowser(){
	new TBrowser();
}
void MyMainFrame::SetFileName(TString FName){
	FileName = FName;
}
void MyMainFrame::OpenFile(TString filename){
	SetFileName(filename);
	LoadFiles();
}


//------------------------------
void DigMonitor(GlobalProcessStatus *gProcessState, TString filename)
{
	// Popup the GUI...
	MyMainFrame *Frame = new MyMainFrame(gClient->GetRoot(), 1000, 1000, gProcessState);
	if(filename != "") Frame->OpenFile(filename);
}

