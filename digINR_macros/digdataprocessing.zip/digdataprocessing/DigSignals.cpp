/*
 * DigSignals.cpp
 *
 *  Created on: May 11, 2016
 *      Author: mss
 */

#include "includes/DigSignals.h"

DigSignalLOGIC::DigSignalLOGIC(int NumChannel_, DigDataRecipe *DataRecipe_ptr_):DigChannel(NumChannel_, DataRecipe_ptr_){
	if(VERBOSE > 0)printf("LOGIC class created for CH%d\n", ThisNumChannel);
}

DigSignalLOGIC::~DigSignalLOGIC(){
	if(VERBOSE > 0)printf("LOGIC class deconstructed for CH%d\n", ThisNumChannel);
}

void DigSignalLOGIC::Reset(){
	this->DigChannel::Reset(); LogicSignal.Reset();
}

int DigSignalLOGIC::GetSignal(LOGIC_signal **Sg_param_ptr){
	*Sg_param_ptr = &LogicSignal;
	return 1;
}


void DigSignalLOGIC::SetBranchSignal(TTree* DataTree){
	DataTree->Branch(ChannelName,&LogicSignal,"Level/F");
}

void DigSignalLOGIC::CalculateSignal(){
	float SLevel = 0, RMSLevel = 0;
	MeanRMScalc(DataBuffer, &SLevel, &RMSLevel, peak_front_stop_p, peak_back_start_p, 1);
	LogicSignal.Level = (SLevel-MainSignal.ZeroLevel)*POLARITY;
}




// -------------------------------------------------
DigSignalAMPLITUDE::DigSignalAMPLITUDE(int NumChannel_, DigDataRecipe *DataRecipe_ptr_):DigChannel(NumChannel_, DataRecipe_ptr_){
	if(VERBOSE > 0)printf("AMPLITUDE class created for CH%d\n", ThisNumChannel);
	AmplProcParam_ptr = DataRecipe_ptr->GetAmplParam(ThisNumChannel);
}

DigSignalAMPLITUDE::~DigSignalAMPLITUDE(){
	if(VERBOSE > 0)printf("AMPLITUDE class deconstructed for CH%d\n", ThisNumChannel);
}

void DigSignalAMPLITUDE::SetBranchSignal(TTree* DataTree){
	DataTree->Branch(ChannelName,&AmplitudeSignal,"LEDtime/F:CFDtime:Charge");
}

void DigSignalAMPLITUDE::Reset(){
	this->DigChannel::Reset(); AmplitudeSignal.Reset();
}

void DigSignalAMPLITUDE::CalculateSignal(){

	//determine LED time
	if(MainSignal.Amplitude > AmplProcParam_ptr->treshold){

		int peak_LED = peak_start_p;
		float ampl_tr = MainSignal.ZeroLevel+AmplProcParam_ptr->treshold/(*AmplitudeDim_ptr)*POLARITY;
		AmplitudeSignal.LEDtime = (*TimeDim_ptr)*GoToLevel(DataBuffer, ampl_tr,  &peak_LED, 1);

	}

	//determine CFD time
	int peak_bipolar = peak_start_p;
	int delay_points = floor(AmplProcParam_ptr->CFD_dt / (*TimeDim_ptr) + .5/*rounding*/);
	//float bipolar_min = 10000;

	if(  (peak_bipolar+delay_points+1) < EVENT_PATTERN_LENGHT){

		while( (peak_bipolar <= peak_stop_p) ){
			float origin_signal =  CurAmpl(peak_bipolar); //(DataBuffer[peak_bipolar]-MainSignal.ZeroLevel)*MainSignal.POLARITY;
			float delated_signal = CurAmpl(peak_bipolar + delay_points); //(DataBuffer[peak_bipolar + delay_points]-MainSignal.ZeroLevel)*MainSignal.POLARITY;
			float bipolar_signal = origin_signal - delated_signal*AmplProcParam_ptr->CFD_fV;

			float origin_signal_ =  CurAmpl(peak_bipolar+1); //(DataBuffer[peak_bipolar+1]-MainSignal.ZeroLevel)*MainSignal.POLARITY;
			float delated_signal_ = CurAmpl(peak_bipolar+1 + delay_points); //(DataBuffer[peak_bipolar+1 + delay_points]-MainSignal.ZeroLevel)*MainSignal.POLARITY;
			float bipolar_signal_ = origin_signal_ - delated_signal_*AmplProcParam_ptr->CFD_fV;

			if(  bipolar_signal*bipolar_signal_ <=  0.  ){
				AmplitudeSignal.CFDtime =  (*TimeDim_ptr)*LevelByTPoints(peak_bipolar, bipolar_signal, peak_bipolar+1,bipolar_signal_,0.);
				break;
			}

			peak_bipolar++;
		} //while

	}

	//determine charhe
	for(int point = peak_start_p; point <= peak_stop_p; point++){

		float ampl_cur = CurAmpl(point); //(DataBuffer[point]-MainSignal.ZeroLevel)*MainSignal.POLARITY;
		// dQ[fC] = dU[mV] * dT[ps] / R[Ω]
		AmplitudeSignal.Charge/*fC*/ += ampl_cur/*mV*/ * (*TimeDim_ptr) /*ps*/ * 0.02/*1/50Ω*/;

	}

};

int DigSignalAMPLITUDE::GetSignal(AMPLITUDE_signal **Sg_param_ptr){
	*Sg_param_ptr = &AmplitudeSignal;
	return 1;
}



// -------------------------------------------------
DigSignalPANELX::DigSignalPANELX(int NumChannel_, DigDataRecipe *DataRecipe_ptr_):DigChannel(NumChannel_, DataRecipe_ptr_){
	if(VERBOSE > 0)printf("PANELX class created for CH%d\n", ThisNumChannel);
}

DigSignalPANELX::~DigSignalPANELX(){
	if(VERBOSE > 0)printf("PANELX class deconstructed for CH%d\n", ThisNumChannel);
}

void DigSignalPANELX::SetBranchSignal(TTree* DataTree){
	DataTree->Branch(ChannelName,&PannelxSignal,"Level/F:Xch/I:Xmm/F");
}

void DigSignalPANELX::CalculateSignal(){
	float SLevel = 0, RMSLevel = 0;
	MeanRMScalc(DataBuffer, &SLevel, &RMSLevel, peak_front_stop_p, peak_back_start_p, 1);
	PannelxSignal.Level = (SLevel-MainSignal.ZeroLevel)*POLARITY;

	PannelxSignal.Xch = CoordinateByLevel( PannelxSignal.Level );
	PannelxSignal.Xmm = PannelxSignal.Xch*8. - 4.;
}

void DigSignalPANELX::Reset(){
	this->DigChannel::Reset();
	PannelxSignal.Reset();
}

int DigSignalPANELX::GetSignal(PANNELX_signal **Sg_param_ptr){
	*Sg_param_ptr = &PannelxSignal;
	return 1;
}



// -------------------------------------------------
DigSignalPANELY::DigSignalPANELY(int NumChannel_, DigDataRecipe *DataRecipe_ptr_):DigChannel(NumChannel_, DataRecipe_ptr_){
	if(VERBOSE > 0)printf("PANELY class created for CH%d\n", ThisNumChannel);
}

DigSignalPANELY::~DigSignalPANELY(){
	if(VERBOSE > 0)printf("PANELY class deconstructed for CH%d\n", ThisNumChannel);
}

void DigSignalPANELY::SetBranchSignal(TTree* DataTree){
	DataTree->Branch(ChannelName,&PannelySignal,"Level/F:Ych/I:Ymm/F");
}

void DigSignalPANELY::CalculateSignal(){
	float SLevel = 0, RMSLevel = 0;
	MeanRMScalc(DataBuffer, &SLevel, &RMSLevel, peak_front_stop_p, peak_back_start_p, 1);
	PannelySignal.Level = (SLevel-MainSignal.ZeroLevel)*POLARITY;

	PannelySignal.Ych = CoordinateByLevel( PannelySignal.Level );
	PannelySignal.Ymm = PannelySignal.Ych*8. - 4.;
}

void DigSignalPANELY::Reset(){
	this->DigChannel::Reset();
	PannelySignal.Reset();
}

int DigSignalPANELY::GetSignal(PANNELY_signal **Sg_param_ptr){
	*Sg_param_ptr = &PannelySignal;
	return 1;
}
