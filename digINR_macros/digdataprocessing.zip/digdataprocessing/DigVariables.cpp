/*
 * DigVariables.cpp
 *
 *  Created on: May 11, 2016
 *      Author: mss
 */

#include "includes/DigVariables.h"

static char ChSignalTypeName[5][MAX_NAME_LENGHT] =
{"UNDEFINED", "LOGIC", "AMPLITUDE", "XY_PANEL_X", "XY_PANEL_Y"};
static char ChPolarityName[2][MAX_NAME_LENGHT] =
{"POSITIVE", "NEGATIVE"};

GlobalProcessStatus::GlobalProcessStatus()
{
	enabled = 0;
	break_flag = 0;
	step = 0;
	percent = 0;
}

GlobalProcessStatus::~GlobalProcessStatus(){

}

int GlobalProcessStatus::GetPercent(){
	return floor(100. * percent);
}

void GlobalProcessStatus::SetStatus(int step_, float percent_){
	step = step_;
	percent = percent_;
	if(enabled)  gSystem->ProcessEvents();
	if(break_flag){break_flag = 0; throw 1;}
}

const char* GlobalProcessStatus::GlobalProcessStatus::GetStepName(){
	switch(step){
	case 0: return "...";
	case 1: return "(1/4) Data processing";
	case 2: return "(2/4) Saving data tree";
	case 3: return "(3/4) Analysing processed data";
	case 4: return "(4/4) Saving analysed data";
	}
	return "(0/0) Incorrect step";
}

ChConfiguration::ChConfiguration(){
	Reset();
}

void ChConfiguration::Reset(){
	strcpy(ChName, "NO NAME");
	strcpy(ChComment, "NO COMMENT");
	strcpy(FileName, "");
	IsEnable = 0;
	ChannelSignalType = UNDEFINED;
	ChannelPolarity = POSITIVE;
}

DataConfiguration::DataConfiguration(){
	Reset();
}

void DataConfiguration::Reset(){
	strcpy(DataName, "NO NAME");
	strcpy(RunComment, "NO COMMENT");
	strcpy(DataPath, "");
	NenableCh = 0;
	NactiveCh = 0;
	IsConfigured = 0;
	for(int ch=0; ch<MAX_CH; ch++) ChannelConfig[ch].Reset();
}

ValueRange::ValueRange(){
	Mean = Sigma = MinValue = MaxValue = 0.;
}

ValueRange::ValueRange(float Mn, float Sg, float Min, float Max){
	Mean = Mn;
	Sigma = Sg;
	MinValue = Min;
	MaxValue = Max;
}

float ValueRange::MinRange(float nSigma){
	return ( (Mean - Sigma*nSigma)<MinValue )?MinValue:(Mean - Sigma*nSigma);
}

float ValueRange::MaxRange(float nSigma){
	return ( (Mean + Sigma*nSigma)>MaxValue )?MaxValue:(Mean + Sigma*nSigma);
}

int ValueRange::InSigmaRange(float Value, float nSigma){
	return (Value > MinRange(nSigma)) &&(Value < MaxRange(nSigma));
}

void ValueRange::PrintOut(){
	printf("[min %.2f, max %.2f](mean %.2f ± sigma %.2f)",MinValue, MaxValue, Mean, Sigma);
}



Fitting_Processing::Fitting_Processing(){
	Reset();
}

void Fitting_Processing::PrintOut(){
	printf("Fitting procedure:   %s\n",FittingON?"ON":"OFF");

	if(FittingON){
		printf("Fitting parameter:   %s\n",parameter);
		printf("Minimal amplitude:   %.1f mV\n",minAmplitude);
		printf("Maximal chisquare:   %.1f\n",MaxChisquare);
		printf("Chisquare range:     %.1f\n",ChiRange);
		printf("Sigma Fit Func:      %.1f ps\n",SigmaFitFunc*1000.);
		printf("Border Fit Rej Time: %.1f\n",BorderFitRejTime);
	}

};

void Fitting_Processing::Reset(){
	FittingON = 0;
	parameter[0] = '\0';
	//sprintf(parameter,"");
	minAmplitude = 0.;
	MaxChisquare = 0.;
	ChiRange = 0.;
	SigmaFitFunc = 0.;
	BorderFitRejTime = 0.;
}



Main_Processing_Param::Main_Processing_Param(){
	Reset();
}

void Main_Processing_Param::PrintOut(){
	printf("Main proc param for CH %i\n",Channel);
	printf("Minimal amplitude:     %.1f mV\n",minAmplitude);
	printf("Maximal amplitude:     %.1f mV\n",maxAmplitude);
	printf("Signal point interval: %.1f * Ampl\n",MainSgnPointsInerval);
	printf("Zero level max RMS:    %.1f mV\n",ZeroLevelmaxRMS);
	printf("POL1 parameters:\n"); POL1.PrintOut();
	printf("POL3 parameters:\n"); POL3.PrintOut();
};



void Main_Processing_Param::Reset(){
	Channel = -1;
	minAmplitude = 0.;
	maxAmplitude = 0.;
	MainSgnPointsInerval = 0.;
	ZeroLevelmaxRMS = 0.;
	POL1.Reset();
	POL3.Reset();
}



Amplitude_Processing_Param::Amplitude_Processing_Param(){
	Reset();
}

void Amplitude_Processing_Param::PrintOut(){
	printf("Amplitude proc param for CH %i\n",Channel);
	printf("LED treshold:               %.1f mv\n",treshold);
	printf("CFD time shift:            -%.1f ns\n",CFD_dt);
	printf("CFD amplitude gain:         %.1f\n",CFD_fV);
};

void Amplitude_Processing_Param::Reset(){
	Channel = -1; treshold = CFD_dt = CFD_fV = 0;
}



DataProcParameters::DataProcParameters(){
	Reset();
}

void DataProcParameters::PrintOut(){
	printf("Amplitude dimension:  %.2f mV/ch\n", AmplitudeDimension);
	printf("Amplitude zero level: %.2f mV\n", AmplitudeZeroLevel);
	printf("Time dimension:       %.2f\n", TimeDimension);
	printf("stat for calc ch conf: %i\n",Statistic);
	printf("Amplitude range:      %.1f * Ampl_sigma\n",AmplRange);
	printf("Aditional points:      %s\n",AddFrontPoints?"ON":"OFF");
	printf("Filter procedure:      %s\n",FilterON?"ON":"OFF");
	if(FilterON) printf("Filter lenght %i, Fs %i, Fx %i\n",Filter_lenght,Filter_Fs,Filter_Fx);
	printf("\n");
	for(int ch = 0; ch<essentialChannels; ch++){
		printf("For channel %s must be: ", essentialChName[ch].Data());
		if(essentialValue[ch] == 0) printf("AMPL ");
		if(essentialValue[ch] == 1) printf("POL1 ");
		if(essentialValue[ch] == 2) printf("POL3 ");
		printf("\n");
	}

}

void DataProcParameters::Reset(){
	AmplitudeDimension = 0.;
	AmplitudeZeroLevel = 0.;
	TimeDimension = 0.;
	FilterON = 0;
	Filter_lenght = Filter_Fs = Filter_Fx = 0;
	AddFrontPoints = 0;
	Statistic = 0;
	AmplRange = 0.;
	essentialChannels = 0;
	for(int ch=0; ch<MAX_CH; ch++){
		essentialChName[ch] = "EMPTY";
		essentialValue[ch] = 0;
	}
}



MAIN_signal::MAIN_signal(){
	Reset();
}

void MAIN_signal::Reset(){
	Amplitude = 0.;
	Time = 0.;
	Time_pol1 = 0.;
	Time_pol3 = 0.;
	ZeroLevel = 0.;
	ZeroLevelRMS = 0.;
	time_peak = 0.;
	time_begin = 0.;
	time_end = 0.;
	time_front_end = 0.;
	time_back_begin = 0.;
};

void MAIN_signal::PrintOut(){
	printf("ampl %.1f ",Amplitude);
	printf("time %.1f ",Time);
	printf("pol1 %.1f ",Time_pol1);
	printf("pol3 %.1f ",Time_pol3);
	printf("ZLvl %.1f ",ZeroLevel);
	printf("ZLRMS %.1f ",ZeroLevelRMS);
	printf("t_peak %.1f ",time_peak);
	printf("t_begin %.1f ",time_begin);
	printf("t_end %.1f ",time_end);
	printf("t_f_end %.1f ",time_front_end);
	printf("t_b_begin %.1f ",time_back_begin);
	printf("\n");
};



LOGIC_signal::LOGIC_signal(){
	Reset();
}

void LOGIC_signal::Reset(){
	Level = 0.;
}



AMPLITUDE_signal::AMPLITUDE_signal(){
	Reset();
}

void AMPLITUDE_signal::Reset(){
	LEDtime = 0.;
	CFDtime = 0.;
	Charge = 0.;
}



PANNELX_signal::PANNELX_signal(){
	Reset();
}

void PANNELX_signal::Reset(){
	Level = 0.;
	Xch = 0.;
	Xmm = 0.;
}



PANNELY_signal::PANNELY_signal(){
	Reset();
}

void PANNELY_signal::Reset(){
	Level = 0.;
	Ych = 0.;
	Ymm = 0.;
}



int AmplitudeData::Check(){//1- event exist
	return (Amplitude != 0.) && (Time_pol1 != 0.);
	/*
return (Amplitude == 0.)
    &&(Time_pol1 == 0.)
    &&(Time_pol1_ATC == 0.);
	 */
}



int LogicalData::Check(){
	return Time_pol1 == 0.;
}
