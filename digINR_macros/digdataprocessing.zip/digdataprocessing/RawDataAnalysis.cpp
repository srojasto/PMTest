
#include "includes/DigData.h"
#include "includes/DigDataAnalysis.h"

#include <TCanvas.h>
#include <TObjArray.h>
#include <TGraph.h>
#include <TF1.h>
#include <TStyle.h>
#include <TFile.h>

int RawDataAnalysis(GlobalProcessStatus *gProcessState){

	printf("\n\n  ---- RawDataAnalysis ---- \n\n");

	// parameters for CFD data analysis

	float AmplTrMCP = 15.;
	//float AmplTrCFD = 400.;
	float AmplTrPMT = 50.;
	TString Path = "/media/data1/Data_Oct_2015/11102015_2051_RUN47_5MCP_radiator53x53_1465V_CFD_tr3mV";
	char TreeFileName[MAXLINE]; strcpy(TreeFileName, Form("%s/DATA_MCPsel%1.0fmV.root",Path.Data(),AmplTrMCP));

	/************************************************************
DigData *Data = new DigData();
DigDataRecipe *DataRecipe_ptr = Data->GetDataRecipe();

//DataRecipe_ptr->AddEssentialChannel("T0_C1",1);
//DataRecipe_ptr->AddEssentialChannel("T0_D1",1);
DataRecipe_ptr->AddEssentialChannel("T0_C2",1);
//DataRecipe_ptr->AddEssentialChannel("T0_D2",1);
DataRecipe_ptr->AddEssentialChannel("T0_Dsc",1);

DataRecipe_ptr->GetProcParam()->AmplRange = 3.;
DataRecipe_ptr->GetMainDetault()->minAmplitude = 0.;
DataRecipe_ptr->GetMainDetault()->POL3.FittingON = 0;


DataRecipe_ptr->Configure(Form("%s/DataConfig.txt",Path.Data()));



//PMT
DataRecipe_ptr->GetMainParam(4)->minAmplitude = AmplTrPMT;
DataRecipe_ptr->GetMainParam(5)->minAmplitude = AmplTrPMT;
DataRecipe_ptr->GetMainParam(12)->minAmplitude = AmplTrPMT;
DataRecipe_ptr->GetMainParam(13)->minAmplitude = AmplTrPMT;
DataRecipe_ptr->GetMainParam(14)->minAmplitude = AmplTrPMT;

//5MCP
DataRecipe_ptr->GetMainParam(0)->minAmplitude = AmplTrMCP;
DataRecipe_ptr->GetMainParam(1)->minAmplitude = AmplTrMCP;
DataRecipe_ptr->GetMainParam(2)->minAmplitude = AmplTrMCP;
DataRecipe_ptr->GetMainParam(3)->minAmplitude = AmplTrMCP;

//CFD
DataRecipe_ptr->GetMainParam(8)->minAmplitude = AmplTrCFD;
DataRecipe_ptr->GetMainParam(9)->minAmplitude = AmplTrCFD;
DataRecipe_ptr->GetMainParam(10)->minAmplitude = AmplTrCFD;
DataRecipe_ptr->GetMainParam(11)->minAmplitude = AmplTrCFD;

DataRecipe_ptr->PrintOut(1);
Data->SaveDataAsTree( TreeFileName ,10000);

delete Data;
***********************************************************/
	DigDataAnalysis *Analysis = new DigDataAnalysis(gProcessState);
	Analysis->SetStudyEv(10000);


	Analysis->AddStartDetector("T0_C1",0);
	Analysis->AddStartDetector("T0_D1",0);

	Analysis->AddStartDetector("T0_C2",1);
	Analysis->AddStartDetector("T0_Dsc",1);

	Analysis->SetAmplMin(0);

	Analysis->AnalyseFile(TreeFileName);




	/************************************************************/


	return 0;
}
