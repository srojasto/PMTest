/*
 * TimeAmplCorr.cpp
 *
 *  Created on: May 11, 2016
 *      Author: mss
 */

#include "includes/TimeAmplCorr.h"

int FinFit(TH1 *HistSl, TF1 *Pol, Int_t X1, Int_t X2, const int maxPow, const int Nfunc){

	const int PrOut = 0; // func printing

	char *eSumPol = new char[Nfunc*70];
	*eSumPol = {0};
	Float_t *Par = new Float_t[Nfunc*(maxPow+1)];
	*Par = {0};
	//Float_t Par[50] = {0};

	Int_t numPar = 0;
	TF1 *CurPol = new TF1();

	for(int func=0; func < Nfunc; func++){
		float Xf1 = X1 + float(func)/Nfunc*(X2-X1);
		float Xf2 = X1 + float(func+1)/Nfunc*(X2-X1);

		Float_t bestCh = 90000;
		Int_t bestPow = 0;
		for(int pow=1; pow <= maxPow; pow++){
			*CurPol = TF1("CurFitPol",Form("pol%d",pow),Xf1,Xf2);
			HistSl->Fit(CurPol,"QRMON");
			Float_t curCh = CurPol->GetChisquare();
			if(PrOut) printf("Func %d, Pow  %d, Ch %f\n",func,pow,curCh);
			if((curCh != 0.) &&(curCh < bestCh)){bestCh = curCh; bestPow = pow;}
		}
		if(PrOut) printf("---> func %d, bestPow %d, bestCh %f\n",func,bestPow,bestCh);
		*CurPol = TF1("CurFitPol",Form("pol%d",bestPow),Xf1,Xf2);
		HistSl->Fit(CurPol,"QRMO");
		for(int curPar=0; curPar <= bestPow + 1; curPar++)
			Par[curPar + numPar] = CurPol->GetParameter(curPar);
		if(func != Nfunc-1) strcat(eSumPol, Form("(x>=%f & x<%f)*pol%d(%d)+",Xf1,Xf2,bestPow,numPar));
		else		strcat(eSumPol, Form("(x>=%f & x<%f)*pol%d(%d)", Xf1,Xf2,bestPow,numPar));
		numPar += bestPow + 1;
	}

	//int n=Nfunc*70; while(eSumPol[n] != '+') n--; eSumPol[n] = ' ';
	if(PrOut) printf("%s\n",eSumPol);
	*Pol = TF1("FitPolynome", eSumPol,X1,X2);
	for(int curPar=0; curPar <= numPar; curPar++){
		Pol -> SetParameter(curPar, Par[curPar]);
		if(PrOut) printf("par%d = %f set(%f)\n", curPar,Par[curPar], Pol -> GetParameter(curPar));
	}

	delete eSumPol;
	delete Par;
	delete CurPol;

	return 1;
}


