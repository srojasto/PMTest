#ifndef ALIT0TIMEAMPLCORR_CPP
#define ALIT0TIMEAMPLCORR_CPP

#include "includes/alit0timeamplcorr.h"

AliT0TimeAmplCorr::AliT0TimeAmplCorr()
{
    SetRangeCFD();
    SetRangeQT1();
    SetRangeVertex();
    SetVerbose();
}

AliT0TimeAmplCorr::~AliT0TimeAmplCorr()
{
    ClearArray( &fMonHists );
    ClearArray( &fProjection );
    ClearArray( &fFunction );
    ClearArray( &fChiTrends );
}

void AliT0TimeAmplCorr::SetNumRUN(Int_t numrun){
	fNumRUN = numrun;
}
void AliT0TimeAmplCorr::SetVerbose(Int_t verbose){
	fVerbose = verbose;
}
TObjArray* AliT0TimeAmplCorr::GetMonHists(){
	return &fMonHists;
}
TObjArray* AliT0TimeAmplCorr::GetProjections(){
	return &fProjection;
}
TObjArray* AliT0TimeAmplCorr::GetFunctions(){
	return &fFunction;
}
void AliT0TimeAmplCorr::SetRangeVertex(Int_t rangevertex){
	frangeVertex = rangevertex;
}
void AliT0TimeAmplCorr::SetRangeCFD(Int_t rangecfd){
	frangeCFD = rangecfd;
}
void AliT0TimeAmplCorr::SetRangeQT1(Int_t rangeqt1){
	frangeQT1 = rangeqt1;
}

Int_t AliT0TimeAmplCorr::AddRAWDataFile(TString filename, TString treename)
{
    if( fTreeChain.AddFile( filename.Data(), 0, treename.Data() ) )
    {
        if(fVerbose >= 2) printf("Tree \"%s\" from file \"%s\" was added\n",treename.Data(), filename.Data());
        return 1;
    }else{
        if(fVerbose >= 1) printf("ERROR: tree \"%s\" from file \"%s\" was NOT added\n",treename.Data(), filename.Data());
        return 0;
    }
}

void AliT0TimeAmplCorr::SaveResultsInFile(TString filename)
{
    if(fVerbose >= 2) printf("\n\nWriting results in file \"%s\" ... \n", filename.Data());
    SaveArrayHistsInFile(&fMonHists, filename, "monHists");
    SaveArrayHistsInFile(&fProjection, filename, "projections");
    SaveArrayHistsInFile(&fFunction, filename, "resultFuncs");
    SaveArrayHistsInFile(&fChiTrends, filename, "CHIgraphs");
}

Int_t AliT0TimeAmplCorr::CollectRAWDataFiles(TString filemask, Int_t numrun, TString treename, Int_t ffirst, Int_t flast)
{

    if(ffirst< 0)ffirst = 0;
    if(flast < ffirst)flast = ffirst;
    if(numrun <= 100000)
    {
        if(fVerbose >= 1) printf("ERROR: unvalid run number: %i\n",numrun);
        return 0;
    } else fNumRUN = numrun;
    //may be filemask check

    Int_t nfilescollect = 0;
    TString currFileName;
    for(Int_t nfile=ffirst; nfile <= flast; nfile++)
    {
        currFileName = Form(filemask.Data(),fNumRUN,nfile);
        if( AddRAWDataFile(currFileName, treename) ) nfilescollect++;
    }

    return nfilescollect;
}

Int_t AliT0TimeAmplCorr::SaveArrayHistsInFile(TObjArray *array, TString filename, TString directoryname)
{
    TFile *file = new TFile(filename.Data(), "UPDATE");

    if(file->IsOpen())
    {
        if(fVerbose >= 2) printf("Writing \"%s\" in file \"%s\"\n", directoryname.Data(), filename.Data());
    }
    else
    {
        if(fVerbose >= 1) printf("ERROR: File \"%s\" was NOT opened for UPDATE\n",filename.Data());
        return 0;
    }

    if(array->GetLast() < 0)
    {
        if(fVerbose >= 1) printf("ERROR: Hist array \"%s\" is empty\n", directoryname.Data());
        return 0;
    }

    file->rmdir(directoryname.Data()); //delete old data to rewrite
    TDirectory *CurrDir = file->mkdir(directoryname.Data()); CurrDir->cd();

    for(Int_t n=0; n<=array->GetLast(); n++)
        if(array->At(n)) array->At(n)->Write();

    file->Close();
    delete file;
    return 1;
}

Int_t AliT0TimeAmplCorr::FitHistogramm(TH1 *histogramm, Float_t &mean, Float_t &sigma)
{
    static const Float_t histFitRange = 2.;    //hists fitted in range mean +/- rms*fitRange
    static const Int_t minFitEvents = 1;    //minimum events in range for fitting
    TF1 fitfunction("fitFunction", "gaus");

    Float_t histMean = histogramm->GetMean();
    Float_t histRMS = histogramm->GetRMS();

    //if too low events for fitting returning 0
    Int_t intBinMin = histogramm->FindBin(histMean-histRMS*histFitRange);
    Int_t intBinMax = histogramm->FindBin(histMean+histRMS*histFitRange);
    Int_t integral =  histogramm->Integral(intBinMin, intBinMax);
    if( integral < minFitEvents){if(fVerbose >= 1)
            printf("ERROR: Too low events in \"%s\" hist: %i\n",histogramm->GetName(), integral); return 0;}

    histogramm->Fit(&fitfunction, "Q", "", histMean-histRMS*histFitRange, histMean+histRMS*histFitRange);

    mean = fitfunction.GetParameter(1);
    sigma = fitfunction.GetParameter(2);

    return 1;
}

Int_t AliT0TimeAmplCorr::GetMeanValuesByFIT()
{

    ClearArray( &fMonHists );

    //procedure parameters:
    static const Int_t histMin = 0;            //minimum for monitor hists
    static const Int_t histMax = 10000;        //maximum for monitor hists
    static const Int_t CHinBin = 5;           //bin wight
    static const Int_t numBinsInHist = ceil((histMax-histMin)/CHinBin); //bins in hists


    //temp variables
    TH1 *ptrTH1curr;                                        //pointers to created hist
    Float_t histmean, histsigma;
    Int_t valMin, valMax;                                 //hist ranges from fitting, may be given fron OCDB, will be class members in future
    TString TREEpmtname, pmtname;                           //pmt name in form "A_9" or "C_12"
    TString TimeCFDeq, AmplitudeQT1eq, AmplitudeQTCeq;      //variables equation for for TTree->Draw():
    TString SelectionCFDeq, SelectionQT1eq, SelectionQTCeq; //selection equation for for TTree->Draw():

    //drawing tvdc hist *****************************************
    if(fVerbose >= 2)printf("Processing TVDC hists ... \n");
    TString tvdcVertexEq = "T0_VERTEX_0";
    fMonHists.Add( ptrTH1curr = new TH1I("tvdc", tvdcVertexEq.Data(), numBinsInHist,histMin,histMax) );
    fTreeChain.Draw( Form("%s>>tvdc", tvdcVertexEq.Data()), Form("0 < %s", tvdcVertexEq.Data()) );

    //values range
    FitHistogramm(ptrTH1curr, histmean, histsigma);
    fMeanVertex = floor(histmean);
    valMin = fMeanVertex - frangeVertex;
    valMax = fMeanVertex + frangeVertex;

    //tvdc selection mean+-frangeVertex
    TString SelectionTVDCeq(  Form("((%i <= %s)&&(%s <= %i))", valMin, tvdcVertexEq.Data(), tvdcVertexEq.Data(), valMax)  );
    ptrTH1curr->GetFunction("fitFunction")->SetRange(valMin, valMax); //to see selected range on func at hist
    if(fVerbose >= 4)printf("TVDC: mean %i; [%i, %i]\n",fMeanVertex, valMin, valMax);


    for(Int_t PMT=0; PMT<NPMT0; PMT++)
    {
        TREEpmtname = Form("%s_%d", (PMT<=11)?"A":"C", (PMT<=11)?PMT+1:PMT-11); //pmt name for branche
        pmtname = Form("%s_%d", (PMT<=11)?"A":"C", (PMT<=11)?PMT+1:PMT-11);  //pmt name for hist name

        if(fVerbose >= 2)printf("Processing %s PMT hists ... \n",pmtname.Data());

        //leafs names
        TimeCFDeq =  Form("(T0_%s_CFD_0)",TREEpmtname.Data());
        AmplitudeQT1eq =  Form("(T0_%s_QT1_0)",TREEpmtname.Data());
        AmplitudeQTCeq =  Form("(T0_%s_QT0_0 - T0_%s_QT1_0)",TREEpmtname.Data(), TREEpmtname.Data()) ;

        //selection equation:
        SelectionCFDeq = Form("(0 < %s)", TimeCFDeq.Data());      //0<CFD initial selection, after fitting, aditional selection will be added
        SelectionQT1eq = Form("(0 < %s)", AmplitudeQT1eq.Data()); //0<QT1
        SelectionQTCeq = Form("(0 < %s)", AmplitudeQTCeq.Data()); //0<QTC



        //constucting projections for fMonHists array:

        //CFD: tvdc selection *****************************************
        fMonHists.Add(  ptrTH1curr = new TH1I(Form("%s_CFD",pmtname.Data()),
                                              Form("CFD_0 PMT_%s;channels;events",pmtname.Data()),numBinsInHist,histMin,histMax)  );
        fTreeChain.Draw( Form("%s >> %s_CFD", TimeCFDeq.Data(), pmtname.Data()),
                         Form("%s&&%s",SelectionCFDeq.Data(),SelectionTVDCeq.Data()) );

        //values range
        FitHistogramm(ptrTH1curr, histmean, histsigma);
        fMeanCFD[PMT] = floor(histmean);
        valMin = fMeanCFD[PMT] - frangeCFD;
        valMax = fMeanCFD[PMT] + frangeCFD;

        //after CFD hist fitted, additional range cut for CFD: mean +- frangeCFD
        SelectionCFDeq += Form("&&((%i <= %s)&&(%s <= %i))", valMin, TimeCFDeq.Data(), TimeCFDeq.Data(), valMax);
        ptrTH1curr->GetFunction("fitFunction")->SetRange(valMin, valMax); //to see selected range on func at hist
        if(fVerbose >= 4)printf("CFD: mean %i; [%i, %i]\n",fMeanCFD[PMT], valMin, valMax);



        //QT1: CFD  && tvdc selection *****************************************
        fMonHists.Add( ptrTH1curr = new TH1I(Form("%s_QT1",pmtname.Data()),
                                             Form("QT1_0 PMT_%s;channels;events",pmtname.Data()),numBinsInHist,histMin,histMax) );
        fTreeChain.Draw( Form("%s >> %s_QT1", AmplitudeQT1eq.Data(), pmtname.Data()),
                         Form("%s&&%s&&%s", SelectionQT1eq.Data(),SelectionCFDeq.Data(), SelectionTVDCeq.Data()) );

        //values range
        FitHistogramm(ptrTH1curr, histmean, histsigma);
        fMeanQT1[PMT] = floor(histmean);
        valMin = fMeanQT1[PMT] - frangeQT1;
        valMax = fMeanQT1[PMT] + frangeQT1;

        //after QT1 hist fitted, additional range cut for QT1 mean +- frangeQT1
        SelectionQT1eq += Form("&&((%i <= %s)&&(%s <= %i))", valMin, AmplitudeQT1eq.Data(), AmplitudeQT1eq.Data(), valMax );
        ptrTH1curr->GetFunction("fitFunction")->SetRange(valMin, valMax); //to see selected range on func at hist
        if(fVerbose >= 4)printf("QT1: mean %i; [%i, %i]\n\n",fMeanQT1[PMT], valMin, valMax);




        //QTC: tvdc && CFD && QT1 selecton, only for monitoring ***************
        fMonHists.Add( ptrTH1curr = new TH1I(Form("%s_QTC",pmtname.Data()),
                                             Form("QTC_0 PMT_%s;channels;events",pmtname.Data()),numBinsInHist,histMin,histMax) );
        fTreeChain.Draw( Form("%s >> %s_QTC", AmplitudeQTCeq.Data(), pmtname.Data()),
                         Form("%s&&%s&&%s&&%s", SelectionQTCeq.Data(), SelectionQT1eq.Data(),SelectionCFDeq.Data(), SelectionTVDCeq.Data()) );


    }//PMT

    return 0;
}

TF1 *AliT0TimeAmplCorr::CreateCorrectionFunction(TH1* sourceprojection, const Int_t maxfuncpower, TString fitoption, TString fragoption, const Int_t maxnslices)
{

    //procedure parameters:
    static const Int_t minBinsInSlice = 6;
    static const Int_t AbsoluteMaxSlices = 101;
    fitoption += "RQN"; //fit option

    if(maxnslices > AbsoluteMaxSlices-1){ if(fVerbose >= 1)printf("ERROR: Too much max value of slices: %i\n",maxnslices); return NULL;}

    Int_t NumTotalEv = sourceprojection->GetEntries();
    if(NumTotalEv < minBinsInSlice){ if(fVerbose >= 1)printf("ERROR: Too low events in \"%s\" hist: %i\n",sourceprojection->GetName(), NumTotalEv); return NULL;}




    //calculate slices ranges, slices edges at bin adges **************************************

    //hist range
    Int_t HistNBins = sourceprojection->GetNbinsX();
    Float_t HistMinX = sourceprojection->GetXaxis()->GetXmin();
    Float_t HistMaxX = sourceprojection->GetXaxis()->GetXmax();

    //mean values for one bin
    Double_t TotErrIntegral = 0; for(Int_t currBin=1; currBin<=HistNBins; currBin++) TotErrIntegral += sourceprojection->GetBinError(currBin);
    Double_t MeanErrIntegralInSlice = TotErrIntegral / (Float_t)maxnslices;//mean error for one slice
    Double_t MeanWidthSlice = (HistMaxX-HistMinX) / (Float_t)maxnslices;
    Int_t MeanBinsInSlice = floor( (Float_t)HistNBins / (Float_t)maxnslices);
    if(MeanBinsInSlice < minBinsInSlice)MeanBinsInSlice = minBinsInSlice;


    //array of hist peak, spaces between which will be divided in slices
    Double_t Peaks[AbsoluteMaxSlices]; //must be remade!!!
    Double_t unsortedPeaks[AbsoluteMaxSlices];
    Int_t sortelements[AbsoluteMaxSlices];
    Int_t TotalPeaks = 0, TotalUnsortPeaks = 0;

    //array of low edges of slices for fitting
    Float_t slices[AbsoluteMaxSlices]; //must be remade!!!
    slices[0] = HistMinX;
    Int_t NumSlices = 1;

    if(fVerbose >= 3)printf("Projection fragmentation ... \n");
    if(fVerbose >= 4)printf("PROJECTION RANGE: %.1f, %.1f\n", HistMinX, HistMaxX);


    if(fragoption.Contains("p")) //searching peaks by maximums and minimums
    {
        TSpectrum spectrum;
        //serching maximums and minimums on projection:
        TH1 *tempProjection = (TH1*)sourceprojection->Clone("tempprojection");
        spectrum.Search(tempProjection, 0.1, "", 0.01);
        Int_t nmaximums = spectrum.GetNPeaks();
        Float_t *maximums = spectrum.GetPositionX();
        for(Int_t max=0;max<nmaximums;max++)unsortedPeaks[TotalUnsortPeaks++] = maximums[max];

        tempProjection->Scale(-1);
        spectrum.Search(tempProjection, 0.1, "", 0.01);
        Int_t nminimums = spectrum.GetNPeaks();
        Float_t *minimums = spectrum.GetPositionX();
        for(Int_t min=0;min<nminimums;min++)unsortedPeaks[TotalUnsortPeaks++] = minimums[min];

        delete tempProjection;

        //formation of the correct sequence of points (summarize arrays and sort them):
        if(nmaximums + nminimums > AbsoluteMaxSlices-4) {printf("ERROR: Too much max and min points in hist: %i\n",nmaximums + nminimums); return NULL;}
        unsortedPeaks[TotalUnsortPeaks++] = HistMaxX;

        TMath::Sort<double, int>(TotalUnsortPeaks, unsortedPeaks, sortelements, kFALSE);

        if(fVerbose >= 4)printf("PEAKS(bin): ");

        //copying sotring array, if bins between peaks less then MinBinInSlice, skip next peak
        Peaks[TotalPeaks++] = HistMinX;
        Int_t fBin, lBin;

        for(Int_t i=0;i<TotalUnsortPeaks-1;i++)
        {
            if(Peaks[TotalPeaks-1] == unsortedPeaks[  sortelements[i]  ]) continue; //current peak is the same

            fBin = sourceprojection->FindBin(  Peaks[TotalPeaks-1]  );
            lBin = sourceprojection->FindBin(  unsortedPeaks[  sortelements[i] ]  );


            if(HistNBins-lBin < minBinsInSlice) //there are not enough space for last slice
            {
                Peaks[TotalPeaks++] = HistMaxX;
                if(fVerbose >= 4)printf("%.1f(%i) ",Peaks[TotalPeaks-1],HistNBins-fBin);
                break;
            }

            if(lBin-fBin < minBinsInSlice) continue; //current slice is too small

            Peaks[TotalPeaks++] = unsortedPeaks[  sortelements[i]  ];
            if(fVerbose >= 4)printf("%.1f(%i) ",Peaks[TotalPeaks-1],lBin-fBin);
        }
        if(fVerbose >= 4)printf("\n");

    }
    else //case no peaks mode
    {
        Peaks[0] = HistMinX;
        Peaks[1] = HistMaxX;
        TotalPeaks = 2;
    }


    //temp variables
    Double_t ErrIntegralInSlice, ErrIntegralLeft; //summ of errors
    Double_t WidthSlice, WidthSliceLeft;
    Int_t BinsInSlice, BinsInSliceLeft;
    Int_t firstBin, lastBin;
    Float_t firstX, lastX;

    // TotalPeaks = 5
    //   0    1        2      3      TotalPeaks-1
    //   O    O        O      O       O   peaks
    //   ******************************   bins
    //   [   ][sli|sli][range][       ]<-------- last bin in last range = (bin-0)
    //       ^                ^
    //       |                |
    //       |             last range begins
    // last bin in         on TotalPeaks-2
    // range = (bin-1)

    for(Int_t peak=0; peak<TotalPeaks-1; peak++) //Peaks[peak] = low edge of range
    {

        //range edges
        //firstBin = sourceprojection->FindBin(Peaks[peak]);
        firstBin = sourceprojection->FindBin(slices[NumSlices-1]);
        lastBin = sourceprojection->FindBin(Peaks[peak+1]) - 1;
        if(peak == TotalPeaks-2)lastBin++; //last bin in last range
        Int_t numBins = lastBin-firstBin;
        firstX = sourceprojection->GetXaxis()->GetBinLowEdge(firstBin);
        lastX = sourceprojection->GetXaxis()->GetBinUpEdge(lastBin);

        //values left
        ErrIntegralLeft = 0;
        for(Int_t currBin=firstBin; currBin<=lastBin; currBin++)
            ErrIntegralLeft += sourceprojection->GetBinError(currBin);
        WidthSliceLeft = lastX-firstX;
        BinsInSliceLeft = numBins;

        //if peak range too small
        if(
            ( (ErrIntegralLeft < MeanErrIntegralInSlice) &&(fragoption.Contains("e")) )||
            ( (WidthSliceLeft < MeanWidthSlice)          &&(fragoption.Contains("r")) )||
            ( (BinsInSliceLeft < MeanBinsInSlice)        &&(fragoption.Contains("b")) )
          ) continue;


        //dividing each range between peaks by mean values
        ErrIntegralInSlice=WidthSlice=BinsInSlice=0;
        for(Int_t currBin=firstBin; currBin<=lastBin; currBin++)
        {

            WidthSlice += sourceprojection->GetBinWidth(currBin);
            WidthSliceLeft -= sourceprojection->GetBinWidth(currBin);
            BinsInSlice += 1;
            BinsInSliceLeft -= 1;
            ErrIntegralInSlice += sourceprojection->GetBinError(currBin);
            ErrIntegralLeft -= sourceprojection->GetBinError(currBin);

            //last slice thrift
            if(
                    ( (ErrIntegralLeft < MeanErrIntegralInSlice) &&(fragoption.Contains("e")) )||
                    ( (WidthSliceLeft < MeanWidthSlice)          &&(fragoption.Contains("r")) )||
                    ( (BinsInSliceLeft < MeanBinsInSlice)        &&(fragoption.Contains("b")) )||
                    (currBin == lastBin)||(BinsInSliceLeft < minBinsInSlice)
                    )
            {
                slices[NumSlices++] = lastX;
                break;
            }

            if(BinsInSlice < minBinsInSlice)continue; //not enougth bins in slice

            //slice saturation contition
            if(
                    ( (ErrIntegralInSlice >= MeanErrIntegralInSlice) &&(fragoption.Contains("e")) )||
                    ( (WidthSlice >= MeanWidthSlice)                 &&(fragoption.Contains("e")) )||
                    ( (BinsInSlice >= MeanBinsInSlice)               &&(fragoption.Contains("e")) )
                    )
            {
                slices[NumSlices++] = sourceprojection->GetXaxis()->GetBinLowEdge(currBin);
                ErrIntegralInSlice = 0;
                WidthSlice = 0;
                BinsInSlice = 0;
            }

        } // for currBin

    } //for peak


    if(fVerbose >= 4)
    {
        printf("SLICES(bin) [%d] : ", NumSlices);
        for(Int_t currslice=1; currslice < NumSlices; currslice++)
            printf("%.1f(%i); ",slices[currslice],
                   sourceprojection->FindBin(slices[currslice]) - sourceprojection->FindBin(slices[currslice-1]));
        printf("\n");
    }


    //fitting each slice with different pow polynome, and choose the best **************************************

    //temp variables
    Float_t X1, X2;
    Double_t currChi, bestChi;
    TF1 currFunction, bestFunction;
    TString resultFuncFormula = "0";

    Double_t resultParameters[2000]; //must be remaid!!!
    for(int i=0;i<2000;i++)resultParameters[i] = 0.;
    Int_t NresultParam = 0;

    if(fVerbose >= 3)printf("Searching best polynomes ... \n");

    for(Int_t currslice=0; currslice < NumSlices-1; currslice++){

        X1 = slices[currslice];
        X2 = slices[currslice+1];
        //printf("%f.1, %f.1\n",X1,X2);

        bestChi = -111;

        for(Int_t currPower=0; currPower<=maxfuncpower; currPower++)
        {

            //printf("CURR POL: %s\n",Form("(x>=%f && x<%f)*pol%d",X1,X2,currPower));
            currFunction = TF1(Form("currfitFunc_%.1f_%.1f",X1,X2), Form("(x>=%f && x<%f)*pol%d",X1,X2,currPower), X1, X2);
            sourceprojection->Fit(&currFunction, fitoption,"",X1,X2);
            //printf("OK\n");

            currChi = currFunction.GetChisquare();
            if(0.00001 < currChi)
            if((currChi < bestChi)||(bestChi == -111)){ bestFunction = currFunction; bestChi = currChi;}

        }//currPower

        if(fVerbose >= 4)printf("[%.1f, %.1f] BEST POW: %i, chi%f\n",X1,X2,bestFunction.GetNpar()-1,bestChi);
        //printf("BEST POLYNOME: %s\n",bestFunction.GetExpFormula("CLING").Data());

        //sourceprojection->Fit(&bestFunction, "Q+","",X1,X2);
        resultFuncFormula += Form("+%s(%d)", bestFunction.GetExpFormula("CLING").Data(),NresultParam);
        for(Int_t par=0; par<bestFunction.GetNpar();par++)
        {
            resultParameters[NresultParam++] = bestFunction.GetParameter(par);
            //printf("par%i: %f\n",NresultParam-1,resultParameters[NresultParam-1]);
        }
        //printf("result rofmula: %s\n",resultFuncFormula.Data());

    }//currFunction

    //printf("RESULT POLYNOME: %s\n",resultFuncFormula.Data());
    TF1 *resultPolynome = new TF1("ResultFitPolynome", resultFuncFormula,HistMinX, HistMaxX);
    resultPolynome->SetParameters(resultParameters);
    //for(Int_t par=0; par<resultPolynome->GetNpar();par++) printf("respar%i: %f\n",par,resultPolynome->GetParameter(par));

    //sourceprojection->Fit(resultPolynome, "Q+","",HistMinX,HistMaxX);
    return resultPolynome;

}

TH1 *AliT0TimeAmplCorr::CreatePojection(TH2 *sourcehist, TString rebinoption, const Float_t minbinevX,
                                        const Float_t minbinevedge, const Int_t rebinX, const Int_t rebinY)
{
    Int_t NumTotalEv = sourcehist->GetEntries();
    if(NumTotalEv < 100)
    {
        printf("ERROR: Too low events in \"%s\" hist: %i\n",sourcehist->GetName(), NumTotalEv);
        return 0;
    }

    TH2 *rebinedhist = sourcehist->Rebin2D(rebinX, rebinY, Form("%s_rebin",sourcehist->GetName()) );

    if(rebinoption.Contains("s"))rebinedhist->Smooth(1);

    Int_t NumBinsY = rebinedhist->GetNbinsY(); //number of bin along CFD
    Int_t NumBinsX = rebinedhist->GetNbinsX(); //number of bin along QTC

    //average events in bin, does not calculated empty bins
    Int_t AverageEvInBinX = 0, bincalculated = 0, integral; //events in bin (QTC axis) on the averages
    for(Int_t xbin = 1; xbin <= NumBinsX; xbin++)
    {
        integral = rebinedhist->Integral(xbin,xbin,1,NumBinsY);
        if(0 < integral){ AverageEvInBinX += integral; bincalculated++;}
    }
    AverageEvInBinX = ceil((Float_t)AverageEvInBinX / (Float_t)bincalculated);


    if(fVerbose >= 4)printf("Average events in bin: %i\n", AverageEvInBinX);

    //fist and last bin with minbinevedge*AverageEvInBinX
    Int_t firstBinX = -1, lastBinX = -1;
    for(Int_t xbin = 1; xbin <= NumBinsX; xbin++)
    {
        if(firstBinX < 0)
            if(ceil(minbinevedge*AverageEvInBinX) <= rebinedhist->Integral(xbin,xbin,1,NumBinsY)) firstBinX = xbin;

        if(lastBinX < 0)
            if(ceil(minbinevedge*AverageEvInBinX) <= rebinedhist->Integral(NumBinsX-xbin+1,NumBinsX-xbin+1,1,NumBinsY)) lastBinX = NumBinsX-xbin+1;

        if( (lastBinX > 0) && (firstBinX > 0) ) break;
    }

    if(fVerbose >= 4)printf("FIRST BIN: %i, %.1f (%.1f ev); LAST BIN: %i, %.1f (%.1f ev)\n",
                          firstBinX, rebinedhist->GetXaxis()->GetBinCenter(firstBinX), rebinedhist->Integral(firstBinX,firstBinX,1,NumBinsY),
                          lastBinX,  rebinedhist->GetXaxis()->GetBinCenter( lastBinX), rebinedhist->Integral(lastBinX, lastBinX, 1,NumBinsY));
    if(rebinoption.Contains("r"))if(fVerbose >= 4)printf("Bin befor rebining: %i\n", lastBinX-firstBinX);

    //finding bins: in each bin minimum minQTCCFDbinEv*QTCCFDnumEvInBinXAverage events
    Float_t NewBinning[10000]; //must be remade !!!
    Int_t eventsINbin = 0, numberOfBins = 0;

    if(fVerbose >= 4)printf("BINNING: ");
    NewBinning[0] = rebinedhist->GetXaxis()->GetBinLowEdge(firstBinX);
    for(Int_t xbin = firstBinX+1; xbin <= lastBinX; xbin++)
    {
        eventsINbin += rebinedhist->Integral(xbin,xbin,1,NumBinsY);

            if( (eventsINbin >= AverageEvInBinX*minbinevX) || (xbin == lastBinX) || (!rebinoption.Contains("r")))
            {
                numberOfBins++;
                NewBinning[numberOfBins] = rebinedhist->GetXaxis()->GetBinUpEdge(xbin);
                if(fVerbose >= 4)printf("%.1f ", NewBinning[numberOfBins]);
                eventsINbin = 0;
            }
    } //for sbin
    if(fVerbose >= 4)printf("\n");
    if(rebinoption.Contains("r"))if(fVerbose >= 4)printf("Bin after rebining: %i\n", numberOfBins);


    //fillin 1D hists with mean and errors by gauss fit
    TH1 *Projection = new TH1F("name","title",numberOfBins,0,1);
    Projection->GetXaxis()->Set(numberOfBins, NewBinning);
    Projection->SetOption("E1");

    Int_t firstbin, lastbin;
    Float_t mean, sigma;
    TH1 *ptrProjectionY;
    for(Int_t bin = 0; bin < numberOfBins; bin++)
    {
        firstbin = rebinedhist->GetXaxis()->FindBin( NewBinning[bin] );
        lastbin = rebinedhist->GetXaxis()->FindBin( NewBinning[bin+1] );

        ptrProjectionY = rebinedhist->ProjectionY(Form("QTCCFDslice_bin_%i_%i",firstbin,lastbin),firstbin,lastbin);
        FitHistogramm(ptrProjectionY,mean,sigma);
        delete ptrProjectionY;

        //sigma /= Projection->GetBinWidth(bin+1);
        sigma *= 0.25;
        Projection->SetBinContent(bin+1,mean);
        Projection->SetBinError(bin+1,sigma);
    }

    delete rebinedhist;

    return Projection;
}

TH2 *AliT0TimeAmplCorr::CreateCFDQTCplot(Int_t pmt)
{
    //procedure parameters:
    static const Int_t QTChistMin = 0;            //minimum for QTC axis (for CFD axis range is fMeanCFD[PMT] - frangeCFD)
    static const Int_t QTChistMax = 10000;        //maximum for QTC axis



    TString TREEpmtname = Form("%s_%d", (pmt<=11)?"A":"C", (pmt<=11)?pmt+1:pmt-11);

    //leafs names
    TString tvdcVertexEq = "T0_VERTEX_0"; //leaf name for vertex
    TString TimeCFDeq =  Form("(T0_%s_CFD_0)",TREEpmtname.Data());
    TString AmplitudeQT1eq =  Form("(T0_%s_QT1_0)",TREEpmtname.Data());
    TString AmplitudeQTCeq =  Form("(T0_%s_QT0_0 - T0_%s_QT1_0)",TREEpmtname.Data(), TREEpmtname.Data()) ;

    //values ranges
    Int_t cfdMin = fMeanCFD[pmt] - frangeCFD;
    Int_t cfdMax = fMeanCFD[pmt] + frangeCFD;

    //selection equation:
    TString SelectionTVDCeq = Form("((%i <= %s)&&(%s <= %i))", fMeanVertex - frangeVertex, tvdcVertexEq.Data(),
                                   tvdcVertexEq.Data(), fMeanVertex + frangeVertex );
    TString SelectionCFDeq = Form("((%i <= %s)&&(%s <= %i))", cfdMin, TimeCFDeq.Data(), TimeCFDeq.Data(), cfdMax );
    TString SelectionQT1eq = Form("((%i <= %s)&&(%s <= %i))", fMeanQT1[pmt] - frangeQT1, AmplitudeQT1eq.Data(),
                                  AmplitudeQT1eq.Data(), fMeanQT1[pmt] + frangeQT1 );
    TString CommonSelection = Form("%s&&%s&&%s", SelectionTVDCeq.Data(), SelectionCFDeq.Data(), SelectionQT1eq.Data());



    //QTC vs CFD:  tvdc && CFD && QT1 selecton
    TH2 *CFDQTCplot = new TH2I(Form("CFDQTCplot_%i",pmt),"",QTChistMax - QTChistMin, QTChistMin,QTChistMax,cfdMax-cfdMin,cfdMin-fMeanCFD[pmt],cfdMax-fMeanCFD[pmt]);
    fTreeChain.Draw( Form("(%s - %i) : %s >> CFDQTCplot_%i", TimeCFDeq.Data(), fMeanCFD[pmt], AmplitudeQTCeq.Data(), pmt), CommonSelection.Data() );

    return CFDQTCplot;
}

TH1 *AliT0TimeAmplCorr::CreateFunctionAssay(TH2 *sourceplot, Double_t &chisquare, TF1 *sourcefunc)
{
    //procedure parameters:
    static const Int_t useFuncRange = 0; //in case function exist, use its range

    TProfile *tempprofile = sourceplot->ProfileX("tempprofile", 1, -1, "o");
    TH1* Projection = tempprofile->ProjectionX("assayprojection", "E");
    delete tempprofile;

    Double_t Xmin = Projection->GetXaxis()->GetXmin();
    Double_t Xmax = Projection->GetXaxis()->GetXmax();

    if(sourcefunc)
    {
        Projection->Add(sourcefunc, -1., "");
        if(useFuncRange)sourcefunc->GetRange(Xmin, Xmax);
    }

    TF1 linearfunc("linearfunc","[0]", Xmin, Xmax);
    Projection->Fit(&linearfunc, "Q", "", Xmin, Xmax);

    chisquare = linearfunc.GetChisquare();
    Projection->SetTitle(Form("[Shisquare = %.1f%s]", chisquare, sourcefunc?"":"(w/o func)"));

    return Projection;
}

Double_t AliT0TimeAmplCorr::TryProjFitOption(TH2 *sourceplot, TH1 **bestprojection, TF1 **bestfunction, TH1 **bestassayhist, TH1 **CHItrend,
                                             Int_t channel, TString projectionoption, TString fragoption, Int_t nslices, Int_t rebinX, Float_t minbinevX)
{
    //not setted parameters
    static const Float_t minBinEvEdge = 0.25;
    static const Int_t rebinY = 5;
    static const Int_t maxFuncPower = 9;
    TString fitoption = "";

    static const Int_t maxAttempts = 10000;

    static Double_t bestChisquare;
    static Int_t lastpmt = -1;
    static Int_t Nattempt = 0;

    if(channel != lastpmt)
    {
        bestChisquare = -111;
        lastpmt = channel;
        Nattempt = 0;
    };

    Nattempt++;
    if(maxAttempts<Nattempt)if(fVerbose >= 1)printf("ERROR: too many points for trend: %i\n", Nattempt);

    TH1 *currProjection;
    TF1 *currFunction;
    TH1 *currAssayHist;

    Double_t currChisquare;
    TString ParString = Form("[N%i, proj:\"%s\" frag:\"%s\" nsl:%i, minEvInBin:%.2f, rX%i]",
                             Nattempt, projectionoption.Data(), fragoption.Data(), nslices, minbinevX, rebinX);

    if(fVerbose >= 2)printf("\nTrying parameters: %s\n", ParString.Data());

    if(fVerbose >= 3)printf("Making projection ... \n");
    currProjection = CreatePojection(sourceplot,projectionoption, minbinevX, minBinEvEdge, rebinX, rebinY);
    if(!currProjection){ if(fVerbose >= 1) printf("ERROR: Projection absent\n"); return 0.;}

    if(fVerbose >= 3)printf("Searching function ... \n");
    currFunction = CreateCorrectionFunction(currProjection, maxFuncPower, fitoption, fragoption, nslices);
    if(!currFunction){ if(fVerbose >= 1) printf("ERROR: Function absent\n"); delete currProjection; return 0.;}

    if(fVerbose >= 3)printf("Assaying function ... \n");
    currAssayHist = CreateFunctionAssay(sourceplot, currChisquare, currFunction);
    if(!currAssayHist){ if(fVerbose >= 1) printf("ERROR: Assay Histogramm absent\n"); delete currProjection; delete currFunction; return 0.;}

    //adding point to trend
    if(CHItrend)
    {
        if( !(*CHItrend) ) *CHItrend = new TH1I(Form("CHItrend_CH%d",channel),Form("Chisquare trend for CH%d",channel), maxAttempts,1,maxAttempts);
        if( Nattempt <= maxAttempts ){
            (*CHItrend)->Fill(ParString.Data(),currChisquare);
            (*CHItrend)->SetAxisRange(1,Nattempt,"X");
        }
    }

    if(fVerbose >= 3)printf("RESULT CHISQUARE: %.1f\n",currChisquare);

    if(  (currChisquare < bestChisquare)||(bestChisquare == -111)  )
    {
        bestChisquare = currChisquare;

        if(*bestprojection) delete *bestprojection;
        if(*bestfunction) delete *bestfunction;
        if(*bestassayhist) delete *bestassayhist;

        TString pmtname = Form("%s_%02d", (channel<=11)?"A":"C", (channel<=11)?channel+1:channel-11);

        currProjection->SetName( Form("%s_QTCCFDprojection", pmtname.Data()) );
        currProjection->SetTitle( Form("QTC vs CFD %s Projection, ch;QTC;CFD", pmtname.Data()) );

        currFunction->SetName( Form("%s_QTCCFDfunction", pmtname.Data()) );
        currFunction->SetTitle( Form("%s Correction function %s", pmtname.Data(), currFunction->GetTitle()) );

        currAssayHist->SetName( Form("%s_func_assay_wif", pmtname.Data()) );
        currAssayHist->SetTitle( Form("%s Function assay %s", pmtname.Data(), currAssayHist->GetTitle()) );

        *bestprojection = currProjection;
        *bestfunction = currFunction;
        *bestassayhist = currAssayHist;
    }
    else
    {
        delete currProjection;
        delete currFunction;
        delete currAssayHist;
    }

    return bestChisquare;

}

Int_t AliT0TimeAmplCorr::MakeTimeAmplCorrection()
{
    if(fVerbose >= 2)printf("\n\n======================== SEARCH AVERAGES ========================\n");
    GetMeanValuesByFIT();

    ClearArray( &fProjection );
    ClearArray( &fFunction );
    ClearArray( &fChiTrends );



    //temp variables
    TString pmtname;
    TH2 *currQTCCFDplot;
    TH1 *currTrend;
    TH1 *bestProjection;
    TF1 *bestFunction;
    TH1 *bestAssayHist;
    Double_t bestChisquare, thebestChisquare;
    TH1 *origAssayHist;

    fChiTrends.Add( new TH1I("stat_nslices","stat of nslices",100,1,100) );
    fChiTrends.Add( new TH1I("stat_rebinX","stat of rebinX",100,1,100) );
    fChiTrends.Add( new TH1I("stat_EvInBin","stat of EvInBin",100,1,100) );
    fChiTrends.Add( new TH1I("stat_rebinopt","stat of rebinopt",100,1,100) );
    fChiTrends.Add( new TH1I("stat_fragopt","stat of fragopt",100,1,100) );

    for(Int_t PMT=0; PMT<NPMT0; PMT++)
    {
        pmtname = Form("%s_%02d", (PMT<=11)?"A":"C", (PMT<=11)?PMT+1:PMT-11);

        if(fVerbose >= 3)printf("\n\n======================== WORKING ON %s ========================\n",pmtname.Data());

        if(fVerbose >= 3)printf("Making 2D CFD-QTC plots ... \n");
        currQTCCFDplot = CreateCFDQTCplot(PMT);
        currQTCCFDplot->SetName( Form("%s_QTCCFD", pmtname.Data()) );
        currQTCCFDplot->SetTitle( Form("QTC vs CFD %s, ch;QTC;CFD", pmtname.Data()) );
        fProjection.Add(currQTCCFDplot);

        //assaying original plot
        origAssayHist = CreateFunctionAssay(currQTCCFDplot,bestChisquare); thebestChisquare = bestChisquare;
        fMonHists.Add(origAssayHist);
        origAssayHist->SetName( Form("%s_func_assay_wof", pmtname.Data()) );
        origAssayHist->SetTitle( Form("%s Function assay %s", pmtname.Data(),
                                      origAssayHist->GetTitle()) );

        bestProjection = NULL;
        bestFunction = NULL;
        bestAssayHist = NULL;
        currTrend = NULL;

        //sorting out parameters
        Int_t slices = 50, bestslices=0;
        Int_t rebinX = 5, bestrebinX=0;
        Float_t EvInBin=5., bestEvInBin=0;
        TString rebinopt, bestrebinopt; Int_t rebinoptN = 2;
        TString fragopt, bestfragopt; Int_t fragoptN = 4;

        //[N1557, proj:"" frag:"e" nsl:45, minEvInBin:5.00, rX5]


        //for(slices = 5; slices<=45; slices += 10)
        for(EvInBin=5.;EvInBin <= 15.; EvInBin += 10.)
        for(rebinX = 10; rebinX<=20; rebinX += 10)
        for(rebinoptN=0;rebinoptN<4;rebinoptN++)
        for(fragoptN=0;fragoptN<8;fragoptN++)
            {
                switch (rebinoptN) {
                case 0: rebinopt = "s";break;
                case 1: rebinopt = "sr";break;
                case 2: rebinopt = "";break;
                case 3: rebinopt = "r";break;
                }

                switch (fragoptN) {
                case 0: fragopt = "pe";break;
                case 1: fragopt = "pr";break;
                case 2: fragopt = "pb";break;
                case 3: fragopt = "perb";break;
                case 4: fragopt = "e";break;
                case 5: fragopt = "r";break;
                case 6: fragopt = "b";break;
                case 7: fragopt = "erb";break;
                }

                bestChisquare = TryProjFitOption(currQTCCFDplot, &bestProjection, &bestFunction, &bestAssayHist, &currTrend,
                                                 PMT, rebinopt, fragopt, slices, rebinX, EvInBin);

                if(bestChisquare<thebestChisquare)
                {
                    thebestChisquare = bestChisquare;
                    bestslices = slices;
                    bestrebinX = rebinX;
                    bestEvInBin = EvInBin;
                    bestrebinopt = rebinopt;
                    bestfragopt = fragopt;
                }

            }//variation


        if(fVerbose >= 3)printf("\nBEST CHISQUARE: %.2f\n",bestChisquare);

        ( (TH1*)fChiTrends.FindObject("stat_nslices") )->Fill(bestslices);
        ( (TH1*)fChiTrends.FindObject("stat_rebinX") )->Fill(bestrebinX);
        ( (TH1*)fChiTrends.FindObject("stat_EvInBin") )->Fill(bestEvInBin);
        ( (TH1*)fChiTrends.FindObject("stat_rebinopt") )->Fill(bestrebinopt,1);
        ( (TH1*)fChiTrends.FindObject("stat_fragopt") )->Fill(bestfragopt,1);

        currTrend->SetAxisRange(currTrend->GetMinimum(1)-100,currTrend->GetMaximum()+100,"Y");
        currTrend->SetTitle( Form("Chisquare trend for PMT %s",pmtname.Data() ));

        fProjection.Add( bestProjection );
        fFunction.Add( bestFunction );
        fMonHists.Add( bestAssayHist );
        fChiTrends.Add( currTrend );

        if(fVerbose >= 2)printf("DONE FOR %s PMT\n\n",pmtname.Data());
    }//PMT
    return 0;
}

void AliT0TimeAmplCorr::ClearArray(TObjArray *array){
	if(0 <= array->GetLast())
		array->RemoveRange(0, array->GetLast());
}


#endif // ALIT0TIMEAMPLCORR_CPP
