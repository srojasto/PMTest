/*
 * DigMonitor.h
 *
 *  Created on: May 18, 2016
 *      Author: mss
 */

#ifndef INCLUDES_DIGMONITOR_H_
#define INCLUDES_DIGMONITOR_H_

#include "DigData.h"
#include "DigDataAnalysis.h"
//#include "DirListFrame.h"

#include <TCanvas.h>
#include <TObjArray.h>
#include <TGraph.h>
#include <TList.h>
#include <string.h>
#include <ctime>

#include<TROOT.h>
#include <TGListBox.h>
#include <TSystem.h>
#include <TApplication.h>
#include <TGClient.h>
#include <TGButton.h>
#include <TGListBox.h>
#include <TGLabel.h>
#include <TRootEmbeddedCanvas.h>
#include <TGTextEntry.h>
#include <TGButton.h>
#include <TGFileDialog.h>
#include <TBrowser.h>
//#include <TTreeViewer.h>
#include <TGNumberEntry.h>
#include <TGButton.h>

#include <stdlib.h>
#include <TGListTree.h>
#include <TGFrame.h>
#include <TFile.h>
#include <TGIcon.h>
#include <TCanvas.h>
#include <TSystem.h>
#include <TPolyMarker.h>
#include <TSystemDirectory.h>
#include <RQ_OBJECT.h>
#include <TTimer.h>
#include <TTime.h>
#include <TGProgressBar.h>


class ParametersFrame : public TGMainFrame{


private:

	GlobalProcessStatus *gProcessState;
	TGNumberEntry *NEstat_p, *NEstat_s, *NEampl_min, *NEampl_rng;
	TGTextEntry *crtlGroupMask;
	TGListBox *LstartCH;
	//TGListBox *LstartCHgr1;

	TGLabel *statusLabel;
	TGTextButton *Bcalculate, *Breset;
	TTimer *Timer;
	TGHProgressBar *ProgressBar;

	DigData *DigEvData;

	int FrameLenght;
	time_t start_time;

	int StatProc, StatSave;

public:

	ParametersFrame(DigData *Data_, const TGWindow *p, UInt_t w, UInt_t h, GlobalProcessStatus *state);
	virtual ~ParametersFrame();

	void CloseWindow();

	void DOreset();
	void DOcalculate();
	void DOtimer();

	ClassDef(ParametersFrame, 0)
};




class MyMainFrame : public TGMainFrame {

private:
	GlobalProcessStatus *gProcessState;
	TRootEmbeddedCanvas *fEcanvas;
	TGLabel *EvLabel1, *EvLabel2, *InfoLabel;
	TGTextEntry       *EvEdit;
	TGListBox *fChannelList;
	TList *ChList;
	TGTextButton *Bstart, *Bstop, *Bstartfb, *Bnext;
	TGCheckButton *IsInspect;
	TGTextButton *Bopen, *Bparameters, *Bbrowser;

	TString FileName;
	DigData *DigEvData;
	int TotalEvents, CurEvent;
	int show_ongoing;
	int show_speed;
	int num_ch_to_show;
	TPolyMarker *SignalMarkers;

	void ShowEvLoop(int EventsToShow = 0);


public:

	MyMainFrame(const TGWindow *p, UInt_t w, UInt_t h, GlobalProcessStatus *state);
	virtual ~MyMainFrame();

	void CloseWindow();

	void ReDivideCanvas();
	void DOstart();
	void DOstop();
	void DOnext();
	void DOcontinue();
	void DOopen();
	void DOparameters();
	void DObrowser();
	void LoadFiles();
	void SetFileName(TString FName);

	void OpenFile(TString filename);

	ClassDef(MyMainFrame, 0)
};

void DigMonitor(GlobalProcessStatus *gProcessState, TString filename = "");




#endif /* INCLUDES_DIGMONITOR_H_ */
