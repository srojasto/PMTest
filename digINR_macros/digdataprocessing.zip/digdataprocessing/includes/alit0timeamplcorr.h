#ifndef ALIT0TIMEAMPLCORR_H
#define ALIT0TIMEAMPLCORR_H

// Time - Amplitude correction
// generate array of time-amplitude projections histograms from raw T0 run data to build time-amplitude correction fuction
// algorithm: build QTC vs CFD histogramm (with selection by tvdc and mean QTC, CFD) and make profile
// profile fitted with array of polynomes

#include<TObjArray.h>
#include<TF1.h>
#include<TH1F.h>
#include<TH2I.h>
#include<TProfile.h>
#include<TString.h>
#include<TChain.h>
#include<TMath.h>
#include<TFile.h>
#include<TSpectrum.h>
#include<TArray.h>
#include<TMath.h>

#define NPMT0 24 //number T0 photomultipliers

//class AliT0TimeAmplCorr;


class AliT0TimeAmplCorr
{
public:
	AliT0TimeAmplCorr();
	virtual ~AliT0TimeAmplCorr();

	//mnagement function:

	//set run number for CDManager
	void SetNumRUN(Int_t numrun);
	//0 - nothing; 1 - errors; 2 - status; 3 - full printing; 4 - calculated values
	void SetVerbose(Int_t verbose = 1);

	//add wad data file to tree, return 1 if successfully, else 0
	Int_t AddRAWDataFile(TString filename, TString treename = "t0tree");

	//collect data files with same name structure, filemask must contains two "%d",
	//in which substituted run and file number respectively, return number of collected files
	Int_t CollectRAWDataFiles(TString filemask, Int_t numrun, TString treename = "t0tree", Int_t ffirst = 0, Int_t flast = 1000);

	//build projections and fit them, return 1 if successfully, else 0
	//delete olds hists on startup
	Int_t MakeTimeAmplCorrection();

	//function for looking over projection and fitting parameters, pointers show to best option
	Double_t TryProjFitOption(TH2 *sourceplot, TH1 **bestprojection, TF1 **bestfunction, TH1 **bestassayhist, TH1 **CHItrend, Int_t channel,
			TString projectionoption, TString fragoption, Int_t nslices, Int_t rebinX, Float_t minbinevX);

	//save all data in file
	void SaveResultsInFile(TString filename);

	TObjArray* GetMonHists();
	TObjArray* GetProjections();
	TObjArray* GetFunctions();


	//setting function:
	void SetRangeVertex(Int_t rangevertex = 800);
	void SetRangeCFD(Int_t rangecfd = 50);
	void SetRangeQT1(Int_t rangeqt1 = 800);

private:
	//processing parameters
	Int_t frangeCFD;
	Int_t frangeVertex;
	Int_t frangeQT1;

	Int_t fVerbose;

	//data variables
	Int_t fNumRUN;
	TChain fTreeChain;

	TObjArray fMonHists; //array of hists for monitoring
	TObjArray fProjection; //QTC-CFD projections for fitting
	TObjArray fFunction; //resulting function for projections
	TObjArray fChiTrends; //array contains trends of bests polynomes chisquare for visual cheking

	Int_t fMeanVertex;
	Int_t fMeanCFD[NPMT0];      //means values finded by hist fitting
	Int_t fMeanQT1[NPMT0];

	//labour procedures and functions:

	//save all TObjArray elements in file in directory replasing all existing element in directory
	Int_t SaveArrayHistsInFile(TObjArray *array, TString filename, TString directoryname);

	//fit one historgam by gauss in range mean+-n*RMS, returm mean and sigma
	Int_t FitHistogramm(TH1 *histogramm, Float_t &mean, Float_t &sigma);

	//Finds mean values by fitting hists and draw hists for monitoring
	Int_t GetMeanValuesByFIT();

	//make plot histogramm CFD vs QTC for fitting by 2D histogramm
	TH2* CreateCFDQTCplot(Int_t pmt);

	//make 1D projecton with spectial binnig for future fitting
	//minbinevX minimum event in bin along X; minbinevedge minimum events in edges bins (in parts of mean events in bin);
	//chinbinY rebinig along Y; rebinoption: s-smoorf 2Dhist, r-with rebinning
	TH1* CreatePojection(TH2* sourcehist, TString rebinoption, const Float_t minbinevX = 5., const Float_t minbinevedge = 0.25,
			const Int_t rebinX = 1, const Int_t rebinY = 1);

	//fit projection by number of polynomes; fragopton p-peak search; e-by errors; r-by ranges; b-by bins;
	TF1* CreateCorrectionFunction(TH1* sourceprojection, const Int_t maxfuncpower=9, TString fitoption="", TString fragoption = "pe", const Int_t nslices=3);

	//check correction function, return chisquare of linear fitting corrected 2D hist (result hist created and must be deleted if need)
	TH1* CreateFunctionAssay(TH2 *sourceplot, Double_t &chisquare, TF1 *sourcefunc = NULL);

	//delete all elements in array
	void ClearArray(TObjArray *array);

};


#endif // ALIT0TIMEAMPLCORR_H
