#ifndef UTILITES_H
#define UTILITES_H

//nclude "TH2F.h"


#include <TClonesArray.h>
#include <TH1F.h>
#include <TCanvas.h>
#include <TStyle.h>
#include <TGraph.h>
#include <TPad.h>
#include <TVirtualPad.h>
#include <TAttLine.h>

bool lessByAbs(Short_t a1, Short_t a2);
int ChrToInt(char A);
double StrToFlt(char *Str);
void HDraw(TObjArray Hist, const char *name, int Hr = 2, int Vt = 2, int Pair = 1, int min = 0, int max = 100, int Log = 0, int Leg = 0, const char *param="");
void HuniDraw(TObjArray Hist, const char *name, int Hr, int Vt, int Pair, int min, int max, int Log, int Leg, const char *param);
void GDraw(TObjArray Hist, const char *name, int Hr, int Vt, int Pair, int min, int max, int Log, int Leg, const char *param);

#endif // UTILITES_H
