

#include <iostream>

class Base
{
public:
    virtual ~Base()
    {
        std::cout << "Base::~Base()" << std::endl;
    }

    virtual void foo() = 0;
};

class Derived : public Base
{
public:
    virtual ~Derived()
    {
        std::cout << "Derived::~Derived()" << std::endl;
    }

    virtual void foo(){std::cout << "Derived::foo()" << std::endl;}
};

int class_text()
{
    Base *base_ptr = new Derived();

    delete base_ptr;

    return 0;
}


//class base
//{
//public:
//    virtual int func(int a){printf("base::func a = %i\n",a);}
//    virtual float func(int a){printf("base::func a = %i\n",a);}

//};

//class Abase :public base
//{
//public:
//    virtual int func(int a){printf("Abase::func a = %i\n",a); return a+1;}

//};

//class Bbase :public base
//{
//public:
//    virtual float func(int a){printf("Bbase::func a = %i\n",a);}
//};


//Int_t class_text()
//{

//    base base_;
//    base_.func(12);

//    Abase Abase_;
//    ( (base)Abase_ ).func(13);

//    base *p = &Abase_;
//    p->func(15.5);

//    return 1;
//}
