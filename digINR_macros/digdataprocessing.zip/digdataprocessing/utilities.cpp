/*
 * utilities.cpp
 *
 *  Created on: May 11, 2016
 *      Author: mss
 */

#include "includes/utilities.h"

bool lessByAbs(Short_t a1, Short_t a2) {
	return TMath::Abs(a1) < TMath::Abs(a2);
}

int ChrToInt(char A){
	switch(A){
	case '0': return 0;
	case '1': return 1;
	case '2': return 2;
	case '3': return 3;
	case '4': return 4;
	case '5': return 5;
	case '6': return 6;
	case '7': return 7;
	case '8': return 8;
	case '9': return 9;
	}
	return -1;
};

double StrToFlt(char *Str){
	int ras = 0;
	double value = 0;

	for(int i = strlen(Str)-1; i>=0; i--){

		if(Str[i] == '-')value *= -1; else
			if(Str[i] == '.'){value /= pow(10,ras); ras=0;}else
			{value += ChrToInt(Str[i])*pow(10,ras); ras++;}
		//cout<<"I "<<i<<" r "<<ras<<" val"<<value<<endl;
	}
	return value;
};

void HDraw(TObjArray Hist, const char *name, int Hr, int Vt, int Pair, int min, int max, int Log, int Leg, const char *param){
	gStyle->SetPalette(1);

	//name, HxV,number paired hits,  min, max,logy, legend (0-no, 1-all, 2-first pad)
	int H_Last = Hist.GetLast();
	if(min < 0) min = 0;
	if(min > H_Last) min = H_Last;
	if(max < 0) max = 0;
	if(max > H_Last) max = H_Last;
	if(Hr < 1) Hr = 1;
	if(Vt < 1) Vt = 1;
	if((Leg == 2)&&(Hr*Vt == 1))Leg = 0;

	TObjArray Canv;
	int flagD = Hr*Vt;

	for(int t=min; t <= max; t++){
		((TH1F*)Hist[t]) -> SetLineWidth(2);
		((TH1F*)Hist[t]) -> SetLineColor(t%Pair +1);
	}

	for(int t=min; t <= max; t++){
		if(++flagD > Hr*Vt){
			char n_Canv[30]; sprintf(n_Canv, "%s#%d",name,Canv.GetLast()+1);
			Canv.Add( new TCanvas(n_Canv, n_Canv, 1000, 1000) );
			((TCanvas*)Canv.Last())->Divide(Hr,Vt);
			flagD = 1;}

		int t_0 = t;
		((TCanvas*)Canv.Last())->cd(flagD);
		((TH1F*)Hist[t])->Draw(param);
		for(int c_Pair = 1; c_Pair < Pair; c_Pair++){
			t++;
			((TH1F*)Hist[t])->Draw("sames");
		}

		//to build big legend on 1st pad drawing hist set twice
		if((Leg == 2)&&(flagD == 1)){
			//gPad -> BuildLegend();
			flagD++;
			t = t_0;
			((TCanvas*)Canv.Last())->cd(flagD);
			((TH1F*)Hist[t])->Draw(param);
			for(int c_Pair = 1; c_Pair < Pair; c_Pair++){
				t++;
				((TH1F*)Hist[t])->Draw("sames");
			}
		}


		if(Log) gPad -> SetLogy(1);
		//if(Leg == 1) ;//gPad -> BuildLegend();

	}

};


void HuniDraw(TObjArray Hist, char *name, int Hr, int Vt, int Pair, int min, int max, int Log, int Leg, const char *param){
	gStyle->SetPalette(1);

	//name, HxV,number paired hits,  min, max,logy, legend (0-no, 1-all, 2-first pad)
	int H_Last = Hist.GetLast();
	if(min < 0) min = 0;
	if(min > H_Last) min = H_Last;
	if(max < 0) max = 0;
	if(max > H_Last) max = H_Last;
	if(Hr < 1) Hr = 1;
	if(Vt < 1) Vt = 1;
	if((Leg == 2)&&(Hr*Vt == 1))Leg = 0;

	TObjArray Canv;
	int flagD = Hr*Vt;

	for(int t=min; t <= max; t++){
		((TH1F*)Hist[t]) -> SetLineWidth(2);
		((TH1F*)Hist[t]) -> SetLineColor(t%Pair +1);
	}

	for(int t=min; t <= max; t++){
		if(++flagD > Hr*Vt){
			char n_Canv[30]; sprintf(n_Canv, "%s#%d",name,Canv.GetLast()+1);
			Canv.Add( new TCanvas(n_Canv, n_Canv, 1000, 1000) );
			((TCanvas*)Canv.Last())->Divide(Hr,Vt);
			flagD = 1;}

		int t_0 = t;
		((TCanvas*)Canv.Last())->cd(flagD);
		((TH1F*)Hist[t])->Draw(param);
		for(int c_Pair = 1; c_Pair < Pair; c_Pair++){
			t++;
			((TH1F*)Hist[t])->Draw("sames");
		}

		//to build big legend on 1st pad drawing hist set twice
		if((Leg == 2)&&(flagD == 1)){
			//gPad -> BuildLegend();
			flagD++;
			t = t_0;
			((TCanvas*)Canv.Last())->cd(flagD);
			((TH1F*)Hist[t])->Draw(param);
			for(int c_Pair = 1; c_Pair < Pair; c_Pair++){
				t++;
				((TH1*)Hist[t])->Draw("sames");
			}
		}


		if(Log) gPad -> SetLogy(1);
		//if(Leg == 1) ;//gPad -> BuildLegend();

	}

};


void GDraw(TObjArray Hist, char *name, int Hr, int Vt, int Pair, int min, int max, int Log, int Leg, const char *param){
	gStyle->SetPalette(1);

	//name, HxV,number paired hits,  min, max,logy, legend (0-no, 1-all, 2-first pad)
	int H_Last = Hist.GetLast();
	if(min < 0) min = 0;
	if(min > H_Last) min = H_Last;
	if(max < 0) max = 0;
	if(max > H_Last) max = H_Last;
	if(Hr < 1) Hr = 1;
	if(Vt < 1) Vt = 1;
	if((Leg == 2)&&(Hr*Vt == 1))Leg = 0;

	TObjArray Canv;
	TPad *curPad;
	int flagD = Hr*Vt;

	for(int t=min; t <= max; t++){
		((TGraph*)Hist[t]) -> SetLineWidth(2);
		//((TAttLine*)Hist[t]) -> SetLineWidth(2);
		((TGraph*)Hist[t]) -> SetLineColor(t%Pair +1);
	}

	for(int t=min; t <= max; t++){
		if(++flagD > Hr*Vt){
			char n_Canv[30]; sprintf(n_Canv, "%s#%d",name,Canv.GetLast()+1);
			Canv.Add( new TCanvas(n_Canv, n_Canv, 1000, 1000) );
			((TCanvas*)Canv.Last())->Divide(Hr,Vt);
			flagD = 1;}

		int t_0 = t;
		curPad = (TPad*)((TCanvas*)Canv.Last())->cd(flagD);
		((TGraph*)Hist[t])->Draw(param);
		Hist[t]->Draw(param);
		for(int c_Pair = 1; c_Pair < Pair; c_Pair++){
			t++;
			((TGraph*)Hist[t])->Draw("same");
		}

		//to build big legend on 1st pad drawing hist set twice
		if((Leg == 2)&&(flagD == 1)){
			curPad -> BuildLegend();
			flagD++;
			t = t_0;
			((TCanvas*)Canv.Last())->cd(flagD);
			((TGraph*)Hist[t])->Draw(param);
			Hist[t]->Draw(param);
			for(int c_Pair = 1; c_Pair < Pair; c_Pair++){
				t++;
				((TGraph*)Hist[t])->Draw("same");
			}
		}


		if(Log) gPad -> SetLogy(1);
		if(Leg == 1) curPad -> BuildLegend();
		//TVirtualPad::Pad().BuildLegend(0.5, 0.6, 0.88, 0.88, "");

	}

};

