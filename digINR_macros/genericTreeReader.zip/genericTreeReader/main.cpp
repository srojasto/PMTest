/*
 * main.cpp
 *
 *  Created on: May 11, 2016
 *      Author: Maciej Slupecki (maciej.slupecki@gmail.com)
 */

#include <iostream>
#include <sstream>
#include <string>
#include <TApplication.h>
#include <TFile.h>
#include <TTree.h>
#include <TBranch.h>
#include <TLeaf.h>
#include <TStyle.h>
#include <TH1D.h>
#include <TH2D.h>
#include <TCanvas.h>

using namespace std;



void PrintUsage(){
	cout << "  <I> === genericTreeReader ===" << endl;
	cout << "  <I>   - Basic example how to read a TTree" << endl;
	cout << "  <I>   - and plot results using histograms." << endl;
	cout << endl;
	cout << "  <I> Command line syntax:" << endl;
	cout << "  <I>   -i                       ---> Path to the input root file." << endl;
	cout << endl;
	cout << "  <I> Examples:" << endl;
	cout << "  <I>   ./genericTreeReader -i=/home/user/sample_file.root" << endl;
	cout << "  <I>   ./genericTreeReader -i=  ---> This will load the default file" << endl;
}



// Command line parser - gets the input file path from the terminal input
int ParseCmdLine(int argc, char* argv[], string& inpath){
	int err = -1;
	if(argc>1){
		for(int i=1; i<argc; i++){
			stringstream sstream(argv[i]);	// [1] safe way to read any user input in c++ (prevents overflows)
			string s;						// [2] safe way to read any user input in c++ (prevents overflows)
			sstream >> s;					// [3] safe way to read any user input in c++ (prevents overflows)
			if(s.size()>2){
				if(s[0] == '-'){
					if(s[1] == 'i'){
						inpath = s.erase(0,3);
						err = 0;			// no error parsing command line
					}
				}
			}
		}
	}

	return err;
}



int ReadAndDraw(string &inpath){
	// if inputfilepath is not given in the commandline, assume the file is located in the same directory as the program
	if(inpath.empty()){
		inpath = "08102015_1758_RUN17_NBI1655frag22_MOD1618frag4_6gevc_collimator_min_3x3.root"; // deafult input path
	}

	cout << "  <I> Opening file: " << inpath << endl;
	TFile *f = new TFile(inpath.c_str(), "READ"); // try opening the root file
	if(f==NULL){
		cout << "<E> Problems opening file." << endl;
		return -1; // exit program
	}

	string treeName = "RawDataTree";
	TTree* t = (TTree*)(f->Get((treeName).c_str())); // get the tree from file
	if(t==NULL){
		cout << "<E> Problems opening tree." << endl;
		return -1; // exit program
	}

	string branchName = "main_5MCP1";
	TBranch* br = t->GetBranch(branchName.c_str());
	if(br==NULL){
		cout << "<E> Problems opening branch:" << branchName << endl;
		return -1; // exit program
	}

	string sAmp = "Amplitude";
	string sTime = "Time_pol1";
	TLeaf *lAmp = br->GetLeaf(sAmp.c_str());
	TLeaf *lTime = br->GetLeaf(sTime.c_str());
	// It should be checked if these leaves exist (similarly to file, tree and branch)
	// Exercise 1: Implement the error check yourself and check if it is working well by
	//             changing sAmp and/or sTime strings to something else (that does not exist in the tree)

	// Now we have all the pointers to the interesting parts of tree (structure)
	// Only leaves contain actual data, all the earlier steps were needed to access leaves

	// Create histograms
	gStyle->SetOptStat("iourmen"); // Turn on everything in the statistic boxes of histos
	TH1D *hAmp = new TH1D("hAmp", "Amplitude histo", 110,0,1100);
	TH1D *hTime = new TH1D("hTime", "Time histo", 120,70,130);
	TH2D *h2TimeAmp = new TH2D("h2TimeAmp", "2D Time-Amp", 120,70,130, 110,0,1100);

	// We can start reading entries of the tree and filling histograms
	int nentries = t->GetEntries();
	for(int evn=0; evn<nentries; evn++){
		if(evn%5000 == 0){
			cout << evn << " (" << 100.*evn/nentries << "%)" << endl; // primitive progress bar
		}
		t->GetEntry(evn); // at this point all our leaf pointers point to the real
		                  // tree data chunk of a given event number (evn)
		double amp = lAmp->GetValue();
		double time = lTime->GetValue();

		// if amp or time is == 0 it means reconstruction failed => treat it as background and ignore
		const double epsilon = 0.001;
		if((time>epsilon) && (amp!=epsilon)){
			hAmp->Fill(amp);
			hTime->Fill(time);
			h2TimeAmp->Fill(time,amp);
		}
	}

	// Draw the results
	TCanvas *cvs = new TCanvas("cvs1", "Time/amplitude data", 1000, 700); // create canvas
	cvs->Divide(2,2);	// Divide canvas into 4 pads (2x2)
	cvs->cd(1);			// activate first pad of the canvas (make it current)
	gPad->SetLogy();	// set y axis to be drawn in a log scale
	hAmp->Draw();		// draw histo on the active pad
	cvs->cd(2);
	gPad->SetLogy();
	hTime->Draw();
	cvs->cd(3);
	gPad->SetLogz();
	h2TimeAmp->Draw("colz");
	// Exercise 2: Add axis labels (x and y) [see: SetXTitle(), https://root.cern.ch/doc/master/classTH1D.html]
	//             Change the line width and color of the 1D histos [see: SetLineWidth(), SetLineColor(), https://root.cern.ch/doc/master/classTColor.html]

	// We can save the printed canvas automatically:
	cvs->SaveAs("cvs.png");

	cerr << "Running interactively..." << endl; // info that the program has finished

	return 0;
}



int main(int argc, char* argv[]){
	string inputFilePath;
	if(ParseCmdLine(argc,argv,inputFilePath) < 0){ 	// handle command line input
		PrintUsage();	// print help to the terminal if cmdline input is not correct
		return -1;		// end the program
	}

	TApplication *theApp = new TApplication("App", &argc, argv);	// needed to print interactive canvases and gui
	theApp->SetIdleTimer(100000,"exit()"); 							// exit automatically after 300 min of being idle
	theApp->SetReturnFromRun(true);									// when the program exits there will be no error message

		if(ReadAndDraw(inputFilePath) < 0){                         // Read file and tree, fill histograms and draw them
			return -1;
		}

	theApp->Run(); // The program now hangs (on purpose) -> it gives the user a chance
	               // to interact with the drawn histograms (otherwise all of the opened
	               // windows would close at the same time as this program closes)
	return 0;
}



// Comments and follow-up:
// 0. Histogram ranges adjusted to run 08102015_1758_RUN17_NBI1655frag22_MOD1618frag4_6gevc_collimator_min_3x3.
//    If different runs are used then the data may be out of range of histos.
// 1. Ignore warnings about missing dictionary. In this simple example they are not relevant.
// 2. You can examine the contents of a root file (also the tree structure) with TBrowser. In terminal write:
//      root
//      new TBrowser
//    A new window will appear. On the left panel find your root file, double click to open, browse at will.
// 3. The time structure looks like uniform distribution between 94 and 106, which is not natural.
//    It is caused by the limited absolute resolution of the trigger channel - according to which
//    the event clock starts and the time of all other channels depends on it.
//    However this bottleneck can be eliminated if we take a relative time differences between signal channels
//    For that reason trigger signals participating in trigger generation are also connected to the signal channels.
//    As you remember the trigger is formed as a logical AND between PMTs called: T0-C and T0-D - see
//    slides 13-14 in the presentation Tutorial, part I (2016.05.23).
//    The branches T0-C and T0-D are available in the tree. Always use branch names with "main_" prefix.
//
//    Usually to further improve data quality and time resolution it is required that both T0-C and T0-D signals
//    are present and their average is used as a reference start time: time_ref = (T0-C.Time + T0-D.Time) / 2
//
//    To remove the aforementioned bottleneck the time_ref should be subtracted from any raw time value taken
//    from any branch of the tree. This way you are calculating the relative time difference between trigger
//    and time recorded in any channel. Now if you fill the histos with these relative times the time resolution
//    will improve significantly and a structure in the spectrum will appear.
//
// Exercise 3. Modify the program and fill the histograms with relative, instead of absolute times.
//             The binning of histograms may need changing (lines 104-106).


